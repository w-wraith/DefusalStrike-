// DEFUSAL STRIKE - Android entry point (NativeActivity + EGL + GLES3)
#include <android/log.h>
#include <android/native_window.h>
#include <android_native_app_glue.h>
#include <EGL/egl.h>
#include <time.h>
#include <unistd.h>
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, "DefusalStrike", __VA_ARGS__)
#include "ui.h"

struct Plat { android_app* app = nullptr; EGLDisplay dpy = EGL_NO_DISPLAY; EGLSurface surf = EGL_NO_SURFACE; EGLContext ctx = EGL_NO_CONTEXT; EGLConfig cfg = nullptr;
  int nw = 1, nh = 1, sw = 1, sh = 1, appliedScale = 100; bool glInit = false; };
static Plat P; static App A; static std::string g_savePath; static double g_last = 0;

static double nowSec() { timespec ts; clock_gettime(CLOCK_MONOTONIC, &ts); return ts.tv_sec + ts.tv_nsec * 1e-9; }

static bool createSurface() {
  ANativeWindow* w = P.app->window; if (!w) return false;
  EGLint fmt = 0; eglGetConfigAttrib(P.dpy, P.cfg, EGL_NATIVE_VISUAL_ID, &fmt);
  ANativeWindow_setBuffersGeometry(w, 0, 0, fmt);                       // reset to native size
  P.nw = ANativeWindow_getWidth(w); P.nh = ANativeWindow_getHeight(w);
  int sc = A.S.renderScale; if (sc < 100) ANativeWindow_setBuffersGeometry(w, P.nw * sc / 100, P.nh * sc / 100, fmt);
  P.surf = eglCreateWindowSurface(P.dpy, P.cfg, w, nullptr); if (P.surf == EGL_NO_SURFACE) return false;
  if (!eglMakeCurrent(P.dpy, P.surf, P.surf, P.ctx)) return false;
  eglQuerySurface(P.dpy, P.surf, EGL_WIDTH, &P.sw); eglQuerySurface(P.dpy, P.surf, EGL_HEIGHT, &P.sh);
  eglSwapInterval(P.dpy, 0); P.appliedScale = sc; return true;
}
static void destroySurface() {
  if (P.dpy == EGL_NO_DISPLAY) return; eglMakeCurrent(P.dpy, EGL_NO_SURFACE, EGL_NO_SURFACE, EGL_NO_CONTEXT);
  if (P.surf != EGL_NO_SURFACE) eglDestroySurface(P.dpy, P.surf); P.surf = EGL_NO_SURFACE;
}
static bool initEGL() {
  if (P.ctx == EGL_NO_CONTEXT) {
    P.dpy = eglGetDisplay(EGL_DEFAULT_DISPLAY); eglInitialize(P.dpy, nullptr, nullptr);
    const EGLint a24[] = {EGL_RENDERABLE_TYPE, EGL_OPENGL_ES3_BIT, EGL_SURFACE_TYPE, EGL_WINDOW_BIT, EGL_RED_SIZE, 8, EGL_GREEN_SIZE, 8, EGL_BLUE_SIZE, 8, EGL_DEPTH_SIZE, 24, EGL_NONE};
    const EGLint a16[] = {EGL_RENDERABLE_TYPE, EGL_OPENGL_ES3_BIT, EGL_SURFACE_TYPE, EGL_WINDOW_BIT, EGL_RED_SIZE, 8, EGL_GREEN_SIZE, 8, EGL_BLUE_SIZE, 8, EGL_DEPTH_SIZE, 16, EGL_NONE};
    EGLint n = 0; if (!eglChooseConfig(P.dpy, a24, &P.cfg, 1, &n) || n < 1) { if (!eglChooseConfig(P.dpy, a16, &P.cfg, 1, &n) || n < 1) return false; }
    const EGLint ca[] = {EGL_CONTEXT_CLIENT_VERSION, 3, EGL_NONE}; P.ctx = eglCreateContext(P.dpy, P.cfg, EGL_NO_CONTEXT, ca); if (P.ctx == EGL_NO_CONTEXT) return false;
  }
  if (!createSurface()) return false;
  if (!P.glInit) { A.g.init(); P.glInit = true; }
  return true;
}

static void onCmd(android_app* app, int32_t cmd) {
  switch (cmd) {
    case APP_CMD_INIT_WINDOW: if (app->window) initEGL(); break;
    case APP_CMD_TERM_WINDOW: destroySurface(); break;
    case APP_CMD_LOST_FOCUS: if (A.mode == M_GAME && A.game.phase != PH_END) { A.paused = true; A.c.reset(); } break;
    case APP_CMD_PAUSE: saveSettings(A.S, g_savePath.c_str()); if (A.mode == M_GAME && A.game.phase != PH_END) { A.paused = true; A.c.reset(); } break;
  }
}
static int32_t onInput(android_app*, AInputEvent* e) {
  int type = AInputEvent_getType(e);
  if (type == AINPUT_EVENT_TYPE_MOTION) {
    int32_t ac = AMotionEvent_getAction(e); int act = ac & AMOTION_EVENT_ACTION_MASK, pi = (ac & AMOTION_EVENT_ACTION_POINTER_INDEX_MASK) >> AMOTION_EVENT_ACTION_POINTER_INDEX_SHIFT;
    float k = A.g.VH / (float)P.nh; size_t cnt = AMotionEvent_getPointerCount(e);
    auto fire = [&](int a, size_t i) { A.c.onEvent(a, AMotionEvent_getPointerId(e, i), AMotionEvent_getX(e, i) * k, AMotionEvent_getY(e, i) * k, A.btns, A.g.VW, A.g.VH, A.S); };
    switch (act) {
      case AMOTION_EVENT_ACTION_DOWN: fire(0, 0); break;
      case AMOTION_EVENT_ACTION_POINTER_DOWN: fire(0, pi); break;
      case AMOTION_EVENT_ACTION_UP: fire(2, 0); break;
      case AMOTION_EVENT_ACTION_POINTER_UP: fire(2, pi); break;
      case AMOTION_EVENT_ACTION_CANCEL: for (size_t i = 0; i < cnt; i++) fire(2, i); break;
      case AMOTION_EVENT_ACTION_MOVE: for (size_t i = 0; i < cnt; i++) fire(1, i); break;
    }
    return 1;
  }
  if (type == AINPUT_EVENT_TYPE_KEY && AKeyEvent_getKeyCode(e) == AKEYCODE_BACK) { if (AKeyEvent_getAction(e) == AKEY_EVENT_ACTION_UP) A.back = true; return 1; }
  return 0;
}

static void frame() {
  double t = nowSec(); float dt = g_last > 0 ? (float)(t - g_last) : 0.016f; g_last = t;
  if (A.S.renderScale != P.appliedScale && !A.c.uiDown) { destroySurface(); if (!createSurface()) return; }
  if (P.surf == EGL_NO_SURFACE) return;
  A.g.begin(P.sw, P.sh); frameApp(A, std::min(dt, .1f));
  eglSwapBuffers(P.dpy, P.surf);
  if (A.saveReq) { A.saveReq = false; saveSettings(A.S, g_savePath.c_str()); }
  if (A.quit) { ANativeActivity_finish(P.app->activity); return; }
  double target = 1.0 / std::max(20, A.S.fpsCap), el = nowSec() - t; if (el < target) usleep((useconds_t)((target - el) * 1e6));
}

void android_main(android_app* app) {
  P.app = app; app->onAppCmd = onCmd; app->onInputEvent = onInput;
  g_savePath = std::string(app->activity->internalDataPath ? app->activity->internalDataPath : "/data/local/tmp") + "/settings.bin";
  loadSettings(A.S, g_savePath.c_str()); A.game.init(&A.S); A.game.startMatch(TEAM_CT); A.game.phase = PH_LIVE; // static scene for the menu background
  while (true) {
    int ev; android_poll_source* src;
    while (ALooper_pollOnce(P.surf != EGL_NO_SURFACE ? 0 : -1, nullptr, &ev, (void**)&src) >= 0) {
      if (src) src->process(app, src);
      if (app->destroyRequested) { saveSettings(A.S, g_savePath.c_str()); destroySurface(); return; }
    }
    if (P.surf != EGL_NO_SURFACE) frame();
  }
}
