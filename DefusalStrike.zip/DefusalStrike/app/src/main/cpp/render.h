// DEFUSAL STRIKE - OpenGL ES renderer (boxes + 2D batch + 5x7 bitmap font)
#pragma once
#include <GLES3/gl3.h>
#include "game.h"
#ifndef LOGE
#define LOGE(...) fprintf(stderr, __VA_ARGS__)
#endif

struct Mat { float m[16]; };
static Mat mIdent() { Mat r; memset(r.m, 0, 64); r.m[0] = r.m[5] = r.m[10] = r.m[15] = 1; return r; }
static Mat mMul(const Mat& a, const Mat& b) { Mat r; for (int c = 0; c < 4; c++) for (int rr = 0; rr < 4; rr++) { float s = 0; for (int k = 0; k < 4; k++) s += a.m[k * 4 + rr] * b.m[c * 4 + k]; r.m[c * 4 + rr] = s; } return r; }
static Mat mTrans(float x, float y, float z) { Mat r = mIdent(); r.m[12] = x; r.m[13] = y; r.m[14] = z; return r; }
static Mat mScale(float x, float y, float z) { Mat r = mIdent(); r.m[0] = x; r.m[5] = y; r.m[10] = z; return r; }
static Mat mRotY(float a) { Mat r = mIdent(); float c = cosf(a), s = sinf(a); r.m[0] = c; r.m[8] = s; r.m[2] = -s; r.m[10] = c; return r; }
static Mat mRotX(float a) { Mat r = mIdent(); float c = cosf(a), s = sinf(a); r.m[5] = c; r.m[9] = -s; r.m[6] = s; r.m[10] = c; return r; }
static Mat mPersp(float fovDeg, float asp, float n, float f) {
  Mat r; memset(r.m, 0, 64); float t = 1.f / tanf(fovDeg * PI / 360.f);
  r.m[0] = t / asp; r.m[5] = t; r.m[10] = (f + n) / (n - f); r.m[11] = -1; r.m[14] = 2 * f * n / (n - f); return r;
}
static Mat mView(V3 e, float yaw, float pit) {
  V3 f = fwdv(yaw, pit), r = {cosf(yaw), 0, sinf(yaw)}, u = cross(r, f); Mat m = mIdent();
  m.m[0] = r.x; m.m[4] = r.y; m.m[8] = r.z; m.m[12] = -dot(r, e);
  m.m[1] = u.x; m.m[5] = u.y; m.m[9] = u.z; m.m[13] = -dot(u, e);
  m.m[2] = -f.x; m.m[6] = -f.y; m.m[10] = -f.z; m.m[14] = dot(f, e); return m;
}
static V3 mXf(const Mat& m, float x, float y, float z) { return {m.m[0] * x + m.m[4] * y + m.m[8] * z + m.m[12], m.m[1] * x + m.m[5] * y + m.m[9] * z + m.m[13], m.m[2] * x + m.m[6] * y + m.m[10] * z + m.m[14]}; }

// 5x7 font, ASCII 32..90 (columns, bit0 = top row)
static const uint8_t FONT[59][5] = {
{0,0,0,0,0},{0,0,0x5F,0,0},{0,7,0,7,0},{0x14,0x7F,0x14,0x7F,0x14},{0x24,0x2A,0x7F,0x2A,0x12},{0x23,0x13,0x08,0x64,0x62},{0x36,0x49,0x56,0x20,0x50},{0,5,3,0,0},
{0,0x1C,0x22,0x41,0},{0,0x41,0x22,0x1C,0},{0x2A,0x1C,0x7F,0x1C,0x2A},{8,8,0x3E,8,8},{0,0x50,0x30,0,0},{8,8,8,8,8},{0,0x60,0x60,0,0},{0x20,0x10,8,4,2},
{0x3E,0x51,0x49,0x45,0x3E},{0,0x42,0x7F,0x40,0},{0x72,0x49,0x49,0x49,0x46},{0x21,0x41,0x49,0x4D,0x33},{0x18,0x14,0x12,0x7F,0x10},{0x27,0x45,0x45,0x45,0x39},{0x3C,0x4A,0x49,0x49,0x31},{0x41,0x21,0x11,9,7},{0x36,0x49,0x49,0x49,0x36},{0x46,0x49,0x49,0x29,0x1E},
{0,0x36,0x36,0,0},{0,0x56,0x36,0,0},{8,0x14,0x22,0x41,0},{0x14,0x14,0x14,0x14,0x14},{0,0x41,0x22,0x14,8},{2,1,0x51,9,6},{0x32,0x49,0x79,0x41,0x3E},
{0x7E,0x11,0x11,0x11,0x7E},{0x7F,0x49,0x49,0x49,0x36},{0x3E,0x41,0x41,0x41,0x22},{0x7F,0x41,0x41,0x22,0x1C},{0x7F,0x49,0x49,0x49,0x41},{0x7F,9,9,9,1},{0x3E,0x41,0x49,0x49,0x7A},{0x7F,8,8,8,0x7F},{0,0x41,0x7F,0x41,0},{0x20,0x40,0x41,0x3F,1},{0x7F,8,0x14,0x22,0x41},{0x7F,0x40,0x40,0x40,0x40},{0x7F,2,0x0C,2,0x7F},
{0x7F,4,8,0x10,0x7F},{0x3E,0x41,0x41,0x41,0x3E},{0x7F,9,9,9,6},{0x3E,0x41,0x51,0x21,0x5E},{0x7F,9,0x19,0x29,0x46},{0x46,0x49,0x49,0x49,0x31},{1,1,0x7F,1,1},{0x3F,0x40,0x40,0x40,0x3F},{0x1F,0x20,0x40,0x20,0x1F},{0x3F,0x40,0x38,0x40,0x3F},{0x63,0x14,8,0x14,0x63},{7,8,0x70,8,7},{0x61,0x51,0x49,0x45,0x43}};

static const char* VS3 = "attribute vec3 aP;attribute vec4 aC;uniform mat4 uM;uniform vec3 uCam;uniform vec3 uFog;varying vec4 vC;varying float vF;"
  "void main(){gl_Position=uM*vec4(aP,1.0);vC=aC;float d=length(aP-uCam);vF=uFog.z>0.5?clamp((d-uFog.x)/(uFog.y-uFog.x),0.0,1.0):0.0;}";
static const char* FS3 = "precision mediump float;uniform vec3 uFogC;varying vec4 vC;varying float vF;void main(){gl_FragColor=vec4(mix(vC.rgb,uFogC,vF),vC.a);}";
static const char* VS2 = "attribute vec2 aP;attribute vec4 aC;uniform vec2 uS;varying vec4 vC;void main(){gl_Position=vec4(aP.x/uS.x*2.0-1.0,1.0-aP.y/uS.y*2.0,0.0,1.0);vC=aC;}";
static const char* FS2 = "precision mediump float;varying vec4 vC;void main(){gl_FragColor=vC;}";
static const float SKY[3] = {.62f, .76f, .92f};

struct Gfx {
  GLuint p3 = 0, p2 = 0, vbo = 0; GLint uM = 0, uCam = 0, uFog = 0, uFogC = 0, uS = 0;
  std::vector<float> v3, v2; float T = 0; float VW = 1280, VH = 720; int pw = 1280, ph = 720;

  static GLuint compile(GLenum t, const char* s) {
    GLuint h = glCreateShader(t); glShaderSource(h, 1, &s, nullptr); glCompileShader(h);
    GLint ok = 0; glGetShaderiv(h, GL_COMPILE_STATUS, &ok); if (!ok) { char b[512]; glGetShaderInfoLog(h, 512, nullptr, b); LOGE("shader: %s", b); } return h;
  }
  static GLuint program(const char* vs, const char* fs) {
    GLuint p = glCreateProgram(); glAttachShader(p, compile(GL_VERTEX_SHADER, vs)); glAttachShader(p, compile(GL_FRAGMENT_SHADER, fs));
    glBindAttribLocation(p, 0, "aP"); glBindAttribLocation(p, 1, "aC"); glLinkProgram(p); return p;
  }
  void init() {
    p3 = program(VS3, FS3); p2 = program(VS2, FS2); glGenBuffers(1, &vbo);
    uM = glGetUniformLocation(p3, "uM"); uCam = glGetUniformLocation(p3, "uCam"); uFog = glGetUniformLocation(p3, "uFog"); uFogC = glGetUniformLocation(p3, "uFogC");
    uS = glGetUniformLocation(p2, "uS");
    glEnable(GL_DEPTH_TEST); glDepthFunc(GL_LEQUAL); glDisable(GL_CULL_FACE); glEnable(GL_BLEND); glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
  }
  void begin(int w, int h) { pw = w; ph = h; VW = VH * (float)w / (float)h; glViewport(0, 0, w, h); }
  void clear(bool color) { glDepthMask(GL_TRUE); glClearColor(SKY[0], SKY[1], SKY[2], 1); glClear(color ? (GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT) : GL_DEPTH_BUFFER_BIT); }

  // ---------------- 3D
  void vert3(V3 p, float r, float g, float b, float a) { v3.push_back(p.x); v3.push_back(p.y); v3.push_back(p.z); v3.push_back(r); v3.push_back(g); v3.push_back(b); v3.push_back(a); }
  void quad3(V3 a, V3 b, V3 c, V3 d, float r, float g, float bl, float al) { vert3(a, r, g, bl, al); vert3(b, r, g, bl, al); vert3(c, r, g, bl, al); vert3(a, r, g, bl, al); vert3(c, r, g, bl, al); vert3(d, r, g, bl, al); }
  void box(const Mat& m, float cx, float cy, float cz, float sx, float sy, float sz, float r, float g, float b, float a = 1) {
    float hx = sx / 2, hy = sy / 2, hz = sz / 2; V3 c[8];
    for (int i = 0; i < 8; i++) c[i] = mXf(m, cx + ((i & 1) ? hx : -hx), cy + ((i & 2) ? hy : -hy), cz + ((i & 4) ? hz : -hz));
    quad3(c[1], c[3], c[7], c[5], r * .85f, g * .85f, b * .85f, a); quad3(c[0], c[2], c[6], c[4], r * .7f, g * .7f, b * .7f, a);
    quad3(c[2], c[3], c[7], c[6], r, g, b, a); quad3(c[0], c[1], c[5], c[4], r * .5f, g * .5f, b * .5f, a);
    quad3(c[4], c[5], c[7], c[6], r * .9f, g * .9f, b * .9f, a); quad3(c[0], c[1], c[3], c[2], r * .65f, g * .65f, b * .65f, a);
  }
  void boxAA(const Box& bx, float k = 1) { static const Mat I = mIdent(); box(I, (bx.x0 + bx.x1) / 2, (bx.y0 + bx.y1) / 2, (bx.z0 + bx.z1) / 2, bx.x1 - bx.x0, bx.y1 - bx.y0, bx.z1 - bx.z0, bx.r * k, bx.g * k, bx.b * k); }
  void ribbon(V3 a, V3 b, float w, float r, float g, float bl, float al) {
    V3 d = b - a; if (len(d) < .01f) return; V3 u0 = fabsf(d.y) < .9f * len(d) ? V3{0, 1, 0} : V3{1, 0, 0};
    V3 rt = norm(cross(d, u0)) * (w / 2), up = norm(cross(rt, d)) * (w / 2);
    quad3(a - rt, a + rt, b + rt, b - rt, r, g, bl, al); quad3(a - up, a + up, b + up, b - up, r, g, bl, al);
  }
  void flush3(const Mat& mvp, V3 cam, bool fog) {
    if (v3.empty()) return; glUseProgram(p3); glUniformMatrix4fv(uM, 1, GL_FALSE, mvp.m); glUniform3f(uCam, cam.x, cam.y, cam.z);
    glUniform3f(uFog, 40, 115, fog ? 1.f : 0.f); glUniform3f(uFogC, SKY[0], SKY[1], SKY[2]);
    glBindBuffer(GL_ARRAY_BUFFER, vbo); glBufferData(GL_ARRAY_BUFFER, v3.size() * 4, v3.data(), GL_STREAM_DRAW);
    glEnableVertexAttribArray(0); glEnableVertexAttribArray(1);
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 28, (void*)0); glVertexAttribPointer(1, 4, GL_FLOAT, GL_FALSE, 28, (void*)12);
    glEnable(GL_DEPTH_TEST); glDrawArrays(GL_TRIANGLES, 0, (GLsizei)(v3.size() / 7)); v3.clear();
  }

  // ---------------- 2D (virtual coords, VH = 720)
  void vert2(float x, float y, float r, float g, float b, float a) { v2.push_back(x); v2.push_back(y); v2.push_back(r); v2.push_back(g); v2.push_back(b); v2.push_back(a); }
  void rect(float x, float y, float w, float h, float r, float g, float b, float a = 1) {
    vert2(x, y, r, g, b, a); vert2(x + w, y, r, g, b, a); vert2(x + w, y + h, r, g, b, a); vert2(x, y, r, g, b, a); vert2(x + w, y + h, r, g, b, a); vert2(x, y + h, r, g, b, a);
  }
  void tri(float x1, float y1, float x2, float y2, float x3, float y3, float r, float g, float b, float a = 1) { vert2(x1, y1, r, g, b, a); vert2(x2, y2, r, g, b, a); vert2(x3, y3, r, g, b, a); }
  void line(float x1, float y1, float x2, float y2, float th, float r, float g, float b, float a = 1) {
    float dx = x2 - x1, dy = y2 - y1, l = sqrtf(dx * dx + dy * dy); if (l < .001f) return; float nx = -dy / l * th / 2, ny = dx / l * th / 2;
    vert2(x1 + nx, y1 + ny, r, g, b, a); vert2(x2 + nx, y2 + ny, r, g, b, a); vert2(x2 - nx, y2 - ny, r, g, b, a);
    vert2(x1 + nx, y1 + ny, r, g, b, a); vert2(x2 - nx, y2 - ny, r, g, b, a); vert2(x1 - nx, y1 - ny, r, g, b, a);
  }
  void disc(float cx, float cy, float rad, float r, float g, float b, float a = 1, int seg = 28) {
    for (int i = 0; i < seg; i++) { float a0 = i * 2 * PI / seg, a1 = (i + 1) * 2 * PI / seg; tri(cx, cy, cx + cosf(a0) * rad, cy + sinf(a0) * rad, cx + cosf(a1) * rad, cy + sinf(a1) * rad, r, g, b, a); }
  }
  void ring(float cx, float cy, float r0, float r1, float r, float g, float b, float a = 1, int seg = 32) {
    for (int i = 0; i < seg; i++) { float a0 = i * 2 * PI / seg, a1 = (i + 1) * 2 * PI / seg; float c0 = cosf(a0), s0 = sinf(a0), c1 = cosf(a1), s1 = sinf(a1);
      tri(cx + c0 * r0, cy + s0 * r0, cx + c0 * r1, cy + s0 * r1, cx + c1 * r1, cy + s1 * r1, r, g, b, a); tri(cx + c0 * r0, cy + s0 * r0, cx + c1 * r1, cy + s1 * r1, cx + c1 * r0, cy + s1 * r0, r, g, b, a); }
  }
  static float textW(const char* s, float sc) { return (float)strlen(s) * 6 * sc - sc; }
  void text(const char* s, float x, float y, float sc, float r, float g, float b, float a = 1, int align = 0, bool shadow = true) {
    if (align == 1) x -= textW(s, sc) / 2; else if (align == 2) x -= textW(s, sc);
    for (int pass = shadow ? 0 : 1; pass < 2; pass++) {
      float ox = pass == 0 ? sc * .6f : 0, cr = pass == 0 ? 0 : r, cg = pass == 0 ? 0 : g, cb = pass == 0 ? 0 : b, ca = pass == 0 ? a * .6f : a;
      float px = x;
      for (const char* p = s; *p; p++, px += 6 * sc) {
        int c = toupper((unsigned char)*p) - 32; if (c < 0 || c > 58) continue;
        for (int col = 0; col < 5; col++) { int bits = FONT[c][col], row = 0;
          while (row < 7) { if (bits & (1 << row)) { int st = row; while (row < 7 && (bits & (1 << row))) row++; rect(px + col * sc + ox, y + st * sc + ox, sc, (row - st) * sc, cr, cg, cb, ca); } else row++; } }
      }
    }
  }
  void flush2() {
    if (v2.empty()) return; glUseProgram(p2); glUniform2f(uS, VW, VH); glDisable(GL_DEPTH_TEST);
    glBindBuffer(GL_ARRAY_BUFFER, vbo); glBufferData(GL_ARRAY_BUFFER, v2.size() * 4, v2.data(), GL_STREAM_DRAW);
    glEnableVertexAttribArray(0); glEnableVertexAttribArray(1);
    glVertexAttribPointer(0, 2, GL_FLOAT, GL_FALSE, 24, (void*)0); glVertexAttribPointer(1, 4, GL_FLOAT, GL_FALSE, 24, (void*)8);
    glDrawArrays(GL_TRIANGLES, 0, (GLsizei)(v2.size() / 6)); v2.clear(); glEnable(GL_DEPTH_TEST);
  }

  // ---------------- models
  void weapon(const Mat& m, int w, float flash) {
    auto B = [&](float cx, float cy, float cz, float sx, float sy, float sz, float r, float g, float b) { box(m, cx, cy, cz, sx, sy, sz, r, g, b); };
    switch (w) {
      case W_KNIFE: B(0, 0, -.2f, .012f, .05f, .3f, .82f, .83f, .88f); B(0, -.015f, .02f, .03f, .04f, .13f, .16f, .12f, .1f); B(0, 0, -.04f, .05f, .015f, .02f, .3f, .3f, .3f); break;
      case W_PISTOL: B(0, .03f, -.1f, .04f, .05f, .22f, .25f, .26f, .28f); B(0, 0, -.08f, .045f, .03f, .18f, .15f, .15f, .17f); B(0, -.06f, .02f, .04f, .11f, .05f, .12f, .1f, .09f); break;
      case W_SMG: B(0, 0, -.2f, .05f, .08f, .4f, .2f, .21f, .23f); B(0, -.1f, -.15f, .03f, .14f, .05f, .12f, .12f, .12f); B(0, -.08f, .03f, .04f, .1f, .04f, .1f, .1f, .1f); B(0, .01f, -.47f, .025f, .025f, .16f, .1f, .1f, .1f); B(0, .055f, -.2f, .02f, .03f, .1f, .08f, .08f, .08f); break;
      case W_RIFLE: B(0, 0, -.3f, .055f, .09f, .6f, .22f, .22f, .24f); B(0, -.01f, -.63f, .06f, .07f, .3f, .45f, .27f, .13f); B(0, .015f, -.88f, .022f, .022f, .22f, .1f, .1f, .1f);
        B(0, -.13f, -.32f, .035f, .16f, .07f, .1f, .1f, .1f); B(0, -.09f, -.02f, .04f, .1f, .05f, .1f, .09f, .08f); B(0, -.02f, .26f, .04f, .1f, .32f, .45f, .27f, .13f); B(0, .065f, -.5f, .015f, .04f, .015f, .06f, .06f, .06f); break;
      case W_SNIPER: B(0, 0, -.4f, .05f, .08f, .9f, .2f, .28f, .2f); B(0, .01f, -1.02f, .02f, .02f, .42f, .1f, .1f, .1f); B(0, .085f, -.4f, .05f, .05f, .32f, .06f, .06f, .07f);
        B(0, .085f, -.57f, .055f, .055f, .02f, .3f, .6f, .9f); B(0, -.02f, .3f, .045f, .1f, .35f, .15f, .2f, .15f); B(0, -.08f, -.3f, .03f, .09f, .06f, .1f, .1f, .1f); break;
      case W_C4: B(0, 0, -.1f, .22f, .08f, .15f, .22f, .26f, .18f); B(0, .045f, -.1f, .12f, .012f, .07f, .05f, .05f, .05f); B(0, .052f, -.1f, .03f, .012f, .03f, fmodf(T, 1.f) < .5f ? 1.f : .2f, 0, 0); B(0, 0, -.1f, .05f, .09f, .17f, .5f, .5f, .5f); break;
    }
    if (flash > 0) { static const float MZ[W_N] = {0, -.25f, -.5f, -.98f, -1.25f, 0}; if (w >= W_PISTOL && w <= W_SNIPER) box(m, 0, .02f, MZ[w] - .06f, .07f, .07f, .12f, 1, .85f, .3f, .9f); }
  }
};

// ======================================================================= scene
static void drawPlayer(Gfx& g, const Game& G, const Player& p, const Settings& S) {
  bool T = p.team == TEAM_T;
  float shirt[3] = {T ? .74f : .2f, T ? .52f : .34f, T ? .2f : .66f}, pants[3] = {T ? .32f : .15f, T ? .26f : .19f, T ? .18f : .32f}, skin[3] = {.9f, .72f, .58f};
  Mat M = mMul(mTrans(p.pos.x, p.pos.y, p.pos.z), mRotY(-p.yaw));
  if (!p.alive) { float f = std::min(1.f, p.deadT * 3.f); M = mMul(mTrans(p.pos.x, p.pos.y + .15f * f, p.pos.z), mMul(mRotY(-p.yaw), mRotX(-f * PI / 2))); }
  else if (S.blob) g.box(mIdent(), p.pos.x, p.pos.y + .015f, p.pos.z, .95f, .02f, .95f, 0, 0, 0, .35f);
  float sw = p.alive ? sinf(p.walkPh) * .7f * std::min(1.f, p.speedNow / 3.f) : 0;
  for (int s = -1; s <= 1; s += 2) { Mat L = mMul(M, mMul(mTrans(s * .12f, .8f, 0), mRotX(s * sw))); g.box(L, 0, -.4f, 0, .2f, .8f, .22f, pants[0], pants[1], pants[2]); }
  g.box(M, 0, 1.1f, 0, .5f, .6f, .28f, shirt[0], shirt[1], shirt[2]);
  if (p.armor > 0) g.box(M, 0, 1.12f, 0, .53f, .4f, .31f, .17f, .17f, .19f);
  float pit = p.alive ? clampf(p.pitch, -1.2f, 1.2f) : 0;
  Mat H = mMul(M, mMul(mTrans(0, 1.58f, 0), mRotX(pit * .6f)));
  g.box(H, 0, 0, 0, .26f, .28f, .26f, skin[0], skin[1], skin[2]);
  g.box(H, 0, .13f, 0, .3f, .1f, .3f, T ? .12f : .12f, T ? .12f : .16f, T ? .12f : .3f);
  Mat A = mMul(M, mMul(mTrans(0, 1.3f, 0), mRotX(pit)));
  g.box(A, -.28f, -.1f, -.22f, .11f, .11f, .5f, shirt[0] * .9f, shirt[1] * .9f, shirt[2] * .9f);
  g.box(A, .2f, -.1f, -.25f, .11f, .11f, .5f, shirt[0] * .9f, shirt[1] * .9f, shirt[2] * .9f);
  g.box(A, .17f, -.1f, -.52f, .09f, .09f, .09f, skin[0], skin[1], skin[2]);
  g.weapon(mMul(A, mTrans(.14f, -.12f, -.3f)), p.cur, p.flash);
  if (p.alive && p.hasBomb) g.box(M, 0, 1.0f, .18f, .2f, .26f, .1f, .25f, .3f, .2f);
}
static void drawBombModel(Gfx& g, V3 p, float t, bool planted) {
  Mat M = mTrans(p.x, p.y + .02f, p.z);
  g.box(M, 0, .1f, 0, .5f, .2f, .35f, .22f, .26f, .18f); g.box(M, 0, .21f, 0, .3f, .02f, .15f, .05f, .05f, .05f);
  bool on = planted ? fmodf(t * (planted ? 3.f : 1.f), 1.f) < .3f : false;
  g.box(M, .17f, .22f, 0, .06f, .03f, .06f, on ? 1.f : .25f, 0, 0); g.box(M, 0, .1f, 0, .15f, .22f, .38f, .45f, .45f, .45f);
}
static void drawViewmodel(Gfx& g, const Game& G, const Settings& S, int vmMode) {
  const Player& p = G.pl[0]; if (vmMode == 1 && (!p.alive || p.scoped)) return;
  int w = vmMode == 2 ? W_RIFLE : p.cur; int team = vmMode == 2 ? G.humanTeam : p.team;
  if (vmMode == 1 && G.useMode(p) != 0 && p.useHeld) w = W_C4;
  float kick = vmMode == 2 ? 0 : p.kick, swap = vmMode == 2 ? 0 : p.swap, sx = S.leftHand ? -1.f : 1.f;
  float bobx = 0, boby = 0; if (S.vmBob && vmMode == 1) { float sp = std::min(1.f, p.speedNow / 4.5f); bobx = sinf(p.walkPh) * .012f * sp; boby = fabsf(cosf(p.walkPh)) * .01f * sp; }
  float dip = 0; if (vmMode == 1 && p.reloading) { float r = 1.f - p.reloadT / std::max(.1f, WD[p.cur].reload); dip = sinf(clampf(r, 0, 1) * PI); }
  float sc = S.vmScale;
  Mat M = mMul(mTrans(sx * (.2f + S.vmX * .02f) + bobx, -.21f + S.vmY * .02f + boby - dip * .12f - swap * .25f, -.4f + S.vmZ * .02f + kick * .05f),
               mMul(mRotX(kick * .09f - swap * .6f - dip * .5f), mMul(mRotY(sx * -.03f), mScale(sx * sc, sc, sc))));
  float sl[3] = {team == TEAM_T ? .74f : .2f, team == TEAM_T ? .52f : .34f, team == TEAM_T ? .2f : .66f}, sk[3] = {.9f, .72f, .58f};
  g.weapon(M, w, vmMode == 1 ? p.flash : 0);
  g.box(M, 0, -.07f, .06f, .075f, .08f, .12f, sk[0], sk[1], sk[2]); g.box(M, .02f, -.13f, .3f, .09f, .09f, .5f, sl[0], sl[1], sl[2]);
  if (w == W_SMG || w == W_RIFLE || w == W_SNIPER || w == W_C4) { g.box(M, 0, -.075f, w == W_C4 ? -.1f : -.3f, .065f, .06f, .1f, sk[0], sk[1], sk[2]); g.box(M, -.08f, -.17f, -.05f, .08f, .08f, .5f, sl[0], sl[1], sl[2]); }
}
static void sceneRender(Gfx& g, const Game& G, const Settings& S, V3 eye, float yaw, float pitch, float fov, int viewIdx, int vmMode) {
  static const Mat I = mIdent(); float asp = (float)g.pw / g.ph;
  g.clear(true); Mat vp = mMul(mPersp(fov, asp, .1f, 160.f), mView(eye, yaw, pitch));
  g.box(I, 0, -.5f, 0, 100, 1, 100, .7f, .62f, .46f);
  for (auto& d : G.map.decor) g.boxAA(d);
  for (int s = 0; s < 2; s++) { int idx = (s == 0 ? 'A' : 'B') - 32; V3 c = G.map.siteC[s]; c.z += 6;
    for (int col = 0; col < 5; col++) for (int row = 0; row < 7; row++) if (FONT[idx][col] & (1 << row)) g.box(I, c.x + (col - 2) * 1.1f, .035f, c.z + (row - 3) * 1.1f, 1.f, .03f, 1.f, .98f, .85f, .3f); }
  for (auto& b : G.map.solids) g.boxAA(b);
  for (int i = 0; i < 10; i++) if (i != viewIdx) drawPlayer(g, G, G.pl[i], S);
  if (G.bomb == B_PLANTED) drawBombModel(g, G.bombPos, G.clock * (1.f + (40.f - G.bombT) * .08f), true);
  else if (G.bomb == B_DROPPED) drawBombModel(g, G.bombPos, G.clock, false);
  for (auto& t : G.tracers) g.ribbon(t.a, t.b, .025f, 1, .9f, .5f, std::min(1.f, t.life * 14.f));
  if (S.particles) for (auto& s : G.sparks) g.box(I, s.p.x, s.p.y, s.p.z, .07f, .07f, .07f, s.r, s.g, s.b);
  if (G.explodeT >= 0 && G.explodeT < 2.5f) { float s = G.explodeT, a = std::max(0.f, 1.f - s / 2.5f) * .55f; Mat R = mMul(mTrans(G.bombPos.x, 1.5f, G.bombPos.z), mRotY(s * 2));
    g.box(R, 0, 0, 0, 3 + s * 16, 3 + s * 14, 3 + s * 16, 1, .45f, .1f, a); g.box(R, 0, 0, 0, 1.5f + s * 8, 1.5f + s * 9, 1.5f + s * 8, 1, .9f, .4f, a); }
  g.flush3(vp, eye, S.fog != 0);
  if (vmMode) { glClear(GL_DEPTH_BUFFER_BIT); drawViewmodel(g, G, S, vmMode); g.flush3(mPersp(S.vmFov, asp, .03f, 10.f), V3{}, false); }
}
