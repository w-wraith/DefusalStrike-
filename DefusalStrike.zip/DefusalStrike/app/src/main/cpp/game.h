// DEFUSAL STRIKE - game logic (platform independent, no GL)
#pragma once
#include <cmath>
#include <cstdio>
#include <cstdint>
#include <cstdlib>
#include <cstring>
#include <vector>
#include <string>
#include <algorithm>

constexpr float PI = 3.14159265f;
struct V3 { float x = 0, y = 0, z = 0; };
static inline V3 operator+(V3 a, V3 b) { return {a.x + b.x, a.y + b.y, a.z + b.z}; }
static inline V3 operator-(V3 a, V3 b) { return {a.x - b.x, a.y - b.y, a.z - b.z}; }
static inline V3 operator*(V3 a, float s) { return {a.x * s, a.y * s, a.z * s}; }
static inline float dot(V3 a, V3 b) { return a.x * b.x + a.y * b.y + a.z * b.z; }
static inline float len(V3 a) { return sqrtf(dot(a, a)); }
static inline V3 cross(V3 a, V3 b) { return {a.y * b.z - a.z * b.y, a.z * b.x - a.x * b.z, a.x * b.y - a.y * b.x}; }
static inline V3 norm(V3 a) { float l = len(a); return l > 1e-6f ? a * (1.f / l) : V3{0, 0, -1}; }
static inline float d2(V3 a, V3 b) { float x = a.x - b.x, z = a.z - b.z; return sqrtf(x * x + z * z); }
static inline V3 fwdv(float yaw, float pit) { float c = cosf(pit); return {sinf(yaw) * c, sinf(pit), -cosf(yaw) * c}; }
static inline float clampf(float v, float a, float b) { return v < a ? a : (v > b ? b : v); }
static inline float angDiff(float a, float b) { float d = fmodf(b - a + PI, 2 * PI); if (d < 0) d += 2 * PI; return d - PI; }
static uint32_t g_rng = 2463534242u;
static inline float rnd() { g_rng ^= g_rng << 13; g_rng ^= g_rng >> 17; g_rng ^= g_rng << 5; return (g_rng & 0xFFFFFF) / 16777216.f; }
static inline float rndr(float a, float b) { return a + (b - a) * rnd(); }
static inline int rndi(int n) { int r = (int)(rnd() * n); return r >= n ? n - 1 : r; }

// ---------------------------------------------------------------- settings
struct Settings {
  uint32_t magic = 0xD3F00007;
  // graphics
  int renderScale = 100, fpsCap = 60, fog = 1, blob = 1, particles = 1, showFps = 0;
  // viewmodel
  float fov = 78, vmFov = 62, vmX = 0, vmY = 0, vmZ = 0, vmScale = 1; int vmBob = 1, leftHand = 0;
  // crosshair
  int chStyle = 0, chColor = 0, chOutline = 1, chDot = 0, chDynamic = 1; float chSize = 9, chThick = 2, chGap = 4, chAlpha = 1;
  // hud
  float hudScale = 1, btnOpacity = 0.5f, minimapSize = 1; int minimap = 1, killfeed = 1, dmgInd = 1, leftFire = 1;
  // controls
  float sens = 1, adsSens = 0.6f, joySize = 1; int invertY = 0, fixedJoy = 0;
  // game / stats
  int difficulty = 1, roundsToWin = 8, wins = 0, losses = 0;
};
static bool loadSettings(Settings& s, const char* path) {
  FILE* f = fopen(path, "rb"); if (!f) return false;
  Settings t; size_t n = fread(&t, 1, sizeof t, f); fclose(f);
  if (n != sizeof t || t.magic != Settings().magic) return false;
  s = t; return true;
}
static void saveSettings(const Settings& s, const char* path) {
  FILE* f = fopen(path, "wb"); if (f) { fwrite(&s, 1, sizeof s, f); fclose(f); }
}

// ---------------------------------------------------------------- weapons
enum { W_KNIFE, W_PISTOL, W_SMG, W_RIFLE, W_SNIPER, W_C4, W_N };
struct WDef { const char* name; float dmg, interval; int mag, res; float reload, spread, recoil, range, speed; int price; bool autof; };
static const WDef WD[W_N] = {
  {"KNIFE", 45, 0.55f, 0, 0, 0, 0, 0, 2.4f, 1.08f, 0, false},
  {"PISTOL", 30, 0.17f, 12, 48, 1.6f, 0.010f, 1.4f, 200, 1.0f, 0, false},
  {"SMG", 21, 0.075f, 30, 120, 2.1f, 0.022f, 0.9f, 200, 0.98f, 1200, true},
  {"RIFLE", 33, 0.098f, 30, 90, 2.5f, 0.016f, 1.5f, 200, 0.92f, 2700, true},
  {"SNIPER", 115, 1.35f, 5, 25, 3.2f, 0.003f, 5.0f, 300, 0.80f, 4750, false},
  {"C4", 0, 1, 0, 0, 0, 0, 0, 0, 1.0f, 0, false}};
static const int BUY_COST[5] = {1200, 2700, 4750, 650, 400};
static const char* BUY_NAME[5] = {"SMG", "RIFLE", "SNIPER", "ARMOR", "DEFUSE KIT"};

// ---------------------------------------------------------------- map
struct Box { float x0, y0, z0, x1, y1, z1, r, g, b; };
static bool rayAABB(V3 o, V3 d, float x0, float y0, float z0, float x1, float y1, float z1, float& tn) {
  float t0 = 0, t1 = 1e9f;
  float oo[3] = {o.x, o.y, o.z}, dd[3] = {d.x, d.y, d.z}, lo[3] = {x0, y0, z0}, hi[3] = {x1, y1, z1};
  for (int i = 0; i < 3; i++) {
    if (fabsf(dd[i]) < 1e-8f) { if (oo[i] < lo[i] || oo[i] > hi[i]) return false; }
    else { float a = (lo[i] - oo[i]) / dd[i], b = (hi[i] - oo[i]) / dd[i]; if (a > b) std::swap(a, b); t0 = std::max(t0, a); t1 = std::min(t1, b); if (t0 > t1) return false; }
  }
  tn = t0; return true;
}
enum { TEAM_T = 0, TEAM_CT = 1 };
struct Map {
  static const int N = 20; static constexpr float CELL = 4.f;
  std::vector<Box> solids, decor; V3 siteC[2]; float siteR = 7.5f; V3 spawn[2][5];
  bool fr[N][N]; uint8_t adj[N][N];
  void add(float cx, float cz, float hx, float hz, float h, float r, float g, float b) { solids.push_back({cx - hx, 0, cz - hz, cx + hx, h, cz + hz, r, g, b}); }
  void addM(float cx, float cz, float hx, float hz, float h, float r, float g, float b) { add(cx, cz, hx, hz, h, r, g, b); if (cx != 0) add(-cx, cz, hx, hz, h, r, g, b); }
  static float nodeX(int i) { return -40.f + CELL * (i + 0.5f); }
  void build() {
    solids.clear(); decor.clear();
    const float W[3] = {.72f, .64f, .5f}, C[3] = {.55f, .38f, .2f}, G[3] = {.58f, .56f, .52f};
    add(0, -40.5f, 41.5f, .5f, 7, .5f, .46f, .4f); add(0, 40.5f, 41.5f, .5f, 7, .5f, .46f, .4f);
    add(-40.5f, 0, .5f, 41.5f, 7, .5f, .46f, .4f); add(40.5f, 0, .5f, 41.5f, 7, .5f, .46f, .4f);
    add(0, -2, 7, 7, 5, G[0], G[1], G[2]);                       // centre block
    addM(16, 8, 1, 10, 4, W[0], W[1], W[2]);                     // lane dividers
    addM(16, 24, 1, 6, 4, W[0], W[1], W[2]);                     // T exit walls
    addM(27, -8, 7, 1, 4, W[0], W[1], W[2]);                     // site buildings
    addM(9, -28, 1, 5, 4, W[0], W[1], W[2]);                     // CT spawn walls
    addM(26, -20, 1.5f, 1.5f, 1.5f, C[0], C[1], C[2]);           // site crates
    addM(31, -24, 1, 1, 1.2f, C[0], C[1], C[2]);
    addM(21, -26, 1, 1.5f, 2.4f, C[0] * .9f, C[1] * .9f, C[2] * .9f);
    addM(34, -16, 1.2f, 1.2f, 1.2f, C[0], C[1], C[2]);
    addM(6, 30, 1.5f, 1.5f, 1.5f, C[0], C[1], C[2]);             // T spawn cover
    addM(28, 8, 2, 2, 1.4f, C[0], C[1], C[2]);                   // lane cover
    addM(11, -14, 1, 1, 3.5f, G[0], G[1], G[2]);                 // pillars
    add(0, 14, 2, 1, 1.2f, C[0], C[1], C[2]);                    // mid cover
    siteC[0] = {-26, 0, -20}; siteC[1] = {26, 0, -20};
    for (int i = 0; i < 5; i++) { spawn[TEAM_T][i] = {-8.f + 4 * i, 0, 34}; spawn[TEAM_CT][i] = {-8.f + 4 * i, 0, -34}; }
    for (int i = 0; i < 8; i++) for (int j = 0; j < 8; j++) { bool a = (i + j) & 1; float s = a ? .78f : .73f; decor.push_back({-40.f + i * 10, 0, -40.f + j * 10, -30.f + i * 10, .012f, -30.f + j * 10, s, s * .91f, s * .66f}); }
    for (int s = 0; s < 2; s++) decor.push_back({siteC[s].x - 8, .012f, siteC[s].z - 8, siteC[s].x + 8, .02f, siteC[s].z + 8, .82f, .55f, .3f});
    buildNav();
  }
  bool circleHit(float x, float z, float r, float y) const {
    for (auto& b : solids) { if (b.y1 <= y + .35f) continue; float nx = clampf(x, b.x0, b.x1), nz = clampf(z, b.z0, b.z1); float dx = x - nx, dz = z - nz; if (dx * dx + dz * dz < r * r) return true; }
    return false;
  }
  float groundAt(float x, float z, float y) const {
    float g = 0; for (auto& b : solids) { if (b.y1 > y + .35f) continue; if (x > b.x0 - .2f && x < b.x1 + .2f && z > b.z0 - .2f && z < b.z1 + .2f) g = std::max(g, b.y1); } return g;
  }
  float rayWorld(V3 o, V3 d, float maxT) const {
    float best = maxT, t;
    for (auto& b : solids) if (rayAABB(o, d, b.x0, b.y0, b.z0, b.x1, b.y1, b.z1, t) && t < best) best = t;
    if (d.y < -1e-5f) { t = -o.y / d.y; if (t > 0 && t < best) best = t; }
    return best;
  }
  bool los(V3 a, V3 b) const { V3 d = b - a; float L = len(d); if (L < .01f) return true; return rayWorld(a, d * (1.f / L), L) >= L - .05f; }
  bool lineFree(float ax, float az, float bx, float bz, float r) const {
    float dx = bx - ax, dz = bz - az, L = sqrtf(dx * dx + dz * dz); int n = (int)(L / .6f) + 1;
    for (int i = 0; i <= n; i++) { float t = (float)i / n; if (circleHit(ax + dx * t, az + dz * t, r, 0)) return false; }
    return true;
  }
  void buildNav() {
    for (int i = 0; i < N; i++) for (int j = 0; j < N; j++) fr[i][j] = !circleHit(nodeX(i), nodeX(j), .75f, 0);
    static const int DX[8] = {1, 1, 0, -1, -1, -1, 0, 1}, DZ[8] = {0, 1, 1, 1, 0, -1, -1, -1};
    for (int i = 0; i < N; i++) for (int j = 0; j < N; j++) {
      adj[i][j] = 0; if (!fr[i][j]) continue;
      for (int k = 0; k < 8; k++) { int nx = i + DX[k], nz = j + DZ[k]; if (nx < 0 || nz < 0 || nx >= N || nz >= N || !fr[nx][nz]) continue; if (lineFree(nodeX(i), nodeX(j), nodeX(nx), nodeX(nz), .55f)) adj[i][j] |= 1 << k; }
    }
  }
  int nodeAt(float x, float z) const {
    int gx = std::min(N - 1, std::max(0, (int)floorf((x + 40) / CELL))), gz = std::min(N - 1, std::max(0, (int)floorf((z + 40) / CELL)));
    if (fr[gx][gz]) return gx * N + gz;
    float best = 1e9f; int bi = 0;
    for (int i = 0; i < N; i++) for (int j = 0; j < N; j++) if (fr[i][j]) { float dx = nodeX(i) - x, dz = nodeX(j) - z, d = dx * dx + dz * dz; if (d < best) { best = d; bi = i * N + j; } }
    return bi;
  }
  bool findPath(V3 from, V3 to, std::vector<V3>& out) const {
    out.clear(); int s = nodeAt(from.x, from.z), t = nodeAt(to.x, to.z);
    int prev[N * N], q[N * N], qh = 0, qt = 0; for (int i = 0; i < N * N; i++) prev[i] = -1;
    static const int DX[8] = {1, 1, 0, -1, -1, -1, 0, 1}, DZ[8] = {0, 1, 1, 1, 0, -1, -1, -1};
    q[qt++] = s; prev[s] = s;
    while (qh < qt) { int c = q[qh++]; if (c == t) break; int cx = c / N, cz = c % N;
      for (int k = 0; k < 8; k++) { if (!(adj[cx][cz] & (1 << k))) continue; int n = (cx + DX[k]) * N + cz + DZ[k]; if (prev[n] >= 0) continue; prev[n] = c; q[qt++] = n; } }
    if (prev[t] < 0) return false;
    std::vector<V3> r; for (int c = t;; c = prev[c]) { r.push_back({nodeX(c / N), 0, nodeX(c % N)}); if (c == s) break; }
    std::reverse(r.begin(), r.end()); out = r; out.push_back(to); return true;
  }
};

// ---------------------------------------------------------------- entities
enum { PH_FREEZE, PH_LIVE, PH_POST, PH_END };
enum { B_CARRIED, B_DROPPED, B_PLANTED, B_DEFUSED, B_EXPLODED };
struct Input { float mx = 0, my = 0, lookX = 0, lookY = 0; bool fire = false, firePressed = false, jump = false, reload = false, use = false, scope = false; int slot = -1; };
struct Player {
  int team = 0, slot = 0; bool human = false, alive = true; char name[12] = "BOT";
  V3 pos; float yaw = 0, pitch = 0, vy = 0; bool onGround = true; float speedNow = 0;
  int hp = 100, armor = 0, money = 800, kills = 0, deaths = 0; bool kit = false, hasBomb = false;
  bool have[W_N] = {}; int mag[W_N] = {}, res[W_N] = {}; int cur = W_PISTOL;
  float fireCd = 0, reloadT = 0; bool reloading = false, scoped = false; float recoil = 0, punch = 0;
  float kick = 0, flash = 0, swap = 0, walkPh = 0, deadT = 0; bool useHeld = false, spotted = false;
  // bot brain
  int target = -1, lastAtk = -1, burst = 0, seenBomb = -1; bool hasGoal = false, visible = false;
  float reactT = 0, scanT = 0, lostT = 0, chaseT = 0, atkT = 0, strafeT = 0, strafeDir = 0, holdT = 0, repathT = 0, stuckT = 0, burstWait = 0, startDelay = 0;
  V3 lastSeen, goal, pathGoal, lastPos; std::vector<V3> path; int pathIdx = 0;
};
struct Tracer { V3 a, b; float life; };
struct Spark { V3 p, v; float life, r, g, b; };
struct Feed { std::string t; int team; float life; bool me; };
static const char* NAMES[20] = {"VIPER", "GHOST", "RAVEN", "BLAZE", "NOVA", "TANK", "SHADOW", "COBRA", "DINGO", "HAWK", "JINX", "KILO", "LYNX", "MAKO", "ONYX", "PIKE", "REAPER", "SAGE", "TITAN", "WOLF"};
static const float BOT_REACT[3] = {0.55f, 0.32f, 0.16f}, BOT_TURN[3] = {5.f, 8.f, 13.f}, BOT_AIM[3] = {0.06f, 0.035f, 0.016f};

struct Game {
  Settings* S = nullptr; Map map; Player pl[10]; int humanTeam = TEAM_CT; int score[2] = {0, 0}; int round = 1;
  int phase = PH_END; float phaseT = 0, roundElapsed = 0, clock = 0, specT = 0;
  int bomb = B_CARRIED; V3 bombPos, plantSpot; float bombT = 0, plantP = 0, defuseP = 0, explodeT = -1; int tSite = 0, defIdx = -1;
  std::vector<Tracer> tracers; std::vector<Spark> sparks; std::vector<Feed> feed;
  std::string msg, msg2; float msgT = 0, hitFlash = 0, hitFromT = 0, hitMarker = 0; V3 hitFrom;
  int spec = -1, lastWinner = -1, roundsToWin = 8; bool matchOver = false, humanWonMatch = false, statsDirty = false, autoHuman = false;
  int statPlants = 0, statDefuses = 0, statBlasts = 0;

  void init(Settings* s) { S = s; map.build(); }
  static V3 eyeOf(const Player& p) { return {p.pos.x, p.pos.y + 1.65f, p.pos.z}; }
  int siteAt(V3 p) const { for (int i = 0; i < 2; i++) if (d2(p, map.siteC[i]) < map.siteR) return i; return -1; }
  bool botCtl(int i) const { return i != 0 || autoHuman; }

  void startMatch(int team) {
    humanTeam = team; score[0] = score[1] = 0; round = 1; matchOver = false; roundsToWin = S ? S->roundsToWin : 8; feed.clear();
    int ni = rndi(20);
    for (int i = 0; i < 10; i++) {
      Player& p = pl[i]; p = Player(); p.team = (i < 5) ? team : 1 - team; p.human = (i == 0); p.money = 800;
      snprintf(p.name, 12, "%s", i == 0 ? "YOU" : NAMES[(ni + i * 3) % 20]);
    }
    startRound(true);
  }
  V3 pickSpot(V3 c, float rmin, float rmax, const V3* losTo) const {
    for (int k = 0; k < 10; k++) {
      float a = rnd() * 2 * PI, r = rndr(rmin, rmax); V3 p = {c.x + cosf(a) * r, 0, c.z + sinf(a) * r};
      if (fabsf(p.x) > 37 || fabsf(p.z) > 37 || map.circleHit(p.x, p.z, .8f, 0)) continue;
      if (losTo && !map.los(p + V3{0, 1.5f, 0}, *losTo + V3{0, .4f, 0})) continue;
      return p;
    }
    return c;
  }
  void startRound(bool first) {
    phase = PH_FREEZE; phaseT = 6.f; roundElapsed = 0; bomb = B_CARRIED; plantP = defuseP = 0; explodeT = -1; defIdx = -1;
    tracers.clear(); sparks.clear(); msg = "GET READY"; msg2 = "BUY TIME"; msgT = 4; hitFlash = 0; hitFromT = 0;
    int cnt[2] = {0, 0};
    for (int i = 0; i < 10; i++) {
      Player& p = pl[i]; bool fresh = first || !p.alive;
      if (fresh) { p.armor = 0; p.kit = false; memset(p.have, 0, sizeof p.have); p.have[W_KNIFE] = p.have[W_PISTOL] = true; }
      for (int w = 0; w < W_N; w++) if (p.have[w]) { p.mag[w] = WD[w].mag; p.res[w] = WD[w].res; }
      p.alive = true; p.hp = 100; p.hasBomb = false; p.deadT = 0; p.vy = 0; p.onGround = true; p.reloading = false; p.scoped = false;
      p.fireCd = .5f; p.recoil = p.punch = 0; p.useHeld = false; p.slot = cnt[p.team]++;
      p.pos = map.spawn[p.team][p.slot]; p.yaw = p.team == TEAM_T ? 0.f : PI; p.pitch = 0; p.swap = 1;
      p.target = -1; p.visible = false; p.hasGoal = false; p.path.clear(); p.holdT = 0; p.chaseT = 0; p.seenBomb = -1; p.startDelay = rndr(0, 1.4f); p.lastPos = p.pos;
      p.cur = p.have[W_SNIPER] ? W_SNIPER : p.have[W_RIFLE] ? W_RIFLE : p.have[W_SMG] ? W_SMG : W_PISTOL;
    }
    int ts[5], n = 0; for (int i = 0; i < 10; i++) if (pl[i].team == TEAM_T) ts[n++] = i;
    pl[ts[rndi(n)]].hasBomb = true;
    tSite = rndi(2); plantSpot = pickSpot(map.siteC[tSite], 2.5f, 5.5f, nullptr);
    for (int i = 1; i < 10; i++) botBuy(pl[i]);
    if (autoHuman) botBuy(pl[0]);
    spec = -1;
  }
  bool canBuy() const { const Player& h = pl[0]; return h.alive && (phase == PH_FREEZE || (phase == PH_LIVE && roundElapsed < 12.f)); }
  void giveWeapon(Player& p, int w) {
    if (w >= W_SMG) for (int k = W_SMG; k <= W_SNIPER; k++) p.have[k] = false;
    p.have[w] = true; p.mag[w] = WD[w].mag; p.res[w] = WD[w].res; selectWeapon(p, w);
  }
  bool buyItem(Player& p, int item) {
    if (p.money < BUY_COST[item]) return false;
    if (item < 3) { int w = W_SMG + item; if (p.have[w]) return false; p.money -= BUY_COST[item]; giveWeapon(p, w); return true; }
    if (item == 3) { if (p.armor >= 100) return false; p.money -= BUY_COST[item]; p.armor = 100; return true; }
    if (p.team != TEAM_CT || p.kit) return false; p.money -= BUY_COST[item]; p.kit = true; return true;
  }
  void botBuy(Player& b) {
    bool hp = b.have[W_SMG] || b.have[W_RIFLE] || b.have[W_SNIPER];
    if (!hp) { if (b.money >= 4750 && rnd() < .25f) buyItem(b, 2); else if (b.money >= 2700) buyItem(b, 1); else if (b.money >= 1200 && rnd() < .7f) buyItem(b, 0); }
    if (b.armor < 50 && b.money >= 650 + (rnd() < .5f ? 0 : 300)) buyItem(b, 3);
    if (b.team == TEAM_CT && !b.kit && b.money >= 400 && rnd() < .5f) buyItem(b, 4);
  }
  int slotWeapon(const Player& p, int slot) const {
    if (slot == 0) return W_KNIFE; if (slot == 1) return W_PISTOL;
    for (int w = W_SNIPER; w >= W_SMG; w--) if (p.have[w]) return w; return -1;
  }
  void selectWeapon(Player& p, int w) { if (!p.have[w] || p.cur == w) return; p.cur = w; p.reloading = false; p.scoped = false; p.fireCd = .4f; p.swap = 1; }
  void startReload(Player& p) {
    const WDef& w = WD[p.cur]; if (w.mag == 0 || p.reloading || p.mag[p.cur] >= w.mag) return;
    if (p.res[p.cur] <= 0) { if (botCtl((int)(&p - pl))) p.res[p.cur] = w.mag; else return; }
    p.reloading = true; p.reloadT = w.reload; p.scoped = false;
  }
  float spreadOf(const Player& p) const {
    const WDef& w = WD[p.cur]; if (w.mag == 0) return 0; float s = w.spread; if (p.cur == W_SNIPER && !p.scoped) s = .08f;
    s += p.recoil * .0035f + p.speedNow * .0022f * (p.cur == W_SNIPER ? 3.f : 1.f); if (!p.onGround) s += .05f; return s;
  }
  int useMode(const Player& p) const {
    if (!p.alive || phase != PH_LIVE) return 0;
    if (p.team == TEAM_T && p.hasBomb && bomb == B_CARRIED && p.onGround && siteAt(p.pos) >= 0) return 1;
    if (p.team == TEAM_CT && bomb == B_PLANTED && d2(p.pos, bombPos) < 2.4f) return 2; return 0;
  }
  void announce(const char* a, const char* b, float t) { msg = a; msg2 = b; msgT = t; }

  // ---- movement
  void moveXZ(Player& p, float dx, float dz) {
    const float r = .42f;
    if (!map.circleHit(p.pos.x + dx, p.pos.z, r, p.pos.y)) p.pos.x += dx;
    if (!map.circleHit(p.pos.x, p.pos.z + dz, r, p.pos.y)) p.pos.z += dz;
    p.pos.x = clampf(p.pos.x, -39.4f, 39.4f); p.pos.z = clampf(p.pos.z, -39.4f, 39.4f);
  }
  void physicsY(Player& p, float dt) {
    float py = p.pos.y; p.vy -= 18.f * dt; p.pos.y += p.vy * dt;
    float g = map.groundAt(p.pos.x, p.pos.z, std::max(py, p.pos.y));
    if (p.pos.y <= g) { p.pos.y = g; p.vy = 0; } p.onGround = p.pos.y <= g + .02f;
  }
  void tick(Player& p, float dt) {
    p.fireCd -= dt; p.kick = std::max(0.f, p.kick - 9 * dt); p.flash -= dt; p.swap = std::max(0.f, p.swap - 4 * dt);
    p.recoil = std::max(0.f, p.recoil - 9 * dt); p.punch -= p.punch * std::min(1.f, 8 * dt); p.atkT -= dt;
    if (p.reloading) { p.reloadT -= dt; if (p.reloadT <= 0) { int need = WD[p.cur].mag - p.mag[p.cur], take = std::min(need, p.res[p.cur]); p.mag[p.cur] += take; p.res[p.cur] -= take; p.reloading = false; } }
    p.walkPh += p.speedNow * dt * 1.8f;
  }

  // ---- combat
  void addFeed(int ki, int vi, int w, bool hs) {
    char b[96]; snprintf(b, 96, "%s [%s%s] %s", ki >= 0 ? pl[ki].name : "BOMB", WD[w].name, hs ? " HS" : "", pl[vi].name);
    feed.push_back({b, ki >= 0 ? pl[ki].team : TEAM_T, 6.f, ki == 0 || vi == 0}); if (feed.size() > 6) feed.erase(feed.begin());
  }
  void die(int vi, int ai, bool head, int w) {
    Player& v = pl[vi]; v.alive = false; v.hp = 0; v.deaths++; v.deadT = 0; v.useHeld = false; v.scoped = false; v.reloading = false;
    if (v.hasBomb) { v.hasBomb = false; bomb = B_DROPPED; bombPos = v.pos; }
    if (ai >= 0 && ai != vi) { pl[ai].kills++; pl[ai].money = std::min(16000, pl[ai].money + 300); }
    addFeed(ai, vi, w, head);
  }
  void hurt(int vi, float dmg, int ai, bool head, int w) {
    Player& v = pl[vi]; if (!v.alive) return; float d = dmg;
    if (v.armor > 0) { d = dmg * .55f; v.armor = std::max(0, v.armor - (int)(dmg * .5f)); }
    v.hp -= (int)ceilf(d);
    if (ai >= 0) {
      if (vi == 0) { hitFlash = .6f; hitFrom = pl[ai].pos; hitFromT = 1.8f; }
      if (ai == 0) hitMarker = .18f;
      if (botCtl(vi)) { v.lastAtk = ai; v.atkT = 3; if (v.target < 0) { v.lastSeen = pl[ai].pos; v.chaseT = 3; } }
    }
    if (v.hp <= 0) die(vi, ai, head, w);
  }
  void spark(V3 p, int n, float r, float g, float b) {
    if (sparks.size() > 150) return;
    for (int i = 0; i < n; i++) sparks.push_back({p, V3{rndr(-2, 2), rndr(0, 3), rndr(-2, 2)}, rndr(.25f, .6f), r, g, b});
  }
  void fireShot(Player& p, float extra) {
    int i = (int)(&p - pl); const WDef& w = WD[p.cur]; p.fireCd = w.interval; V3 o = eyeOf(p); bool gun = w.mag > 0;
    p.kick = 1; if (gun) { p.mag[p.cur]--; p.flash = .06f; p.recoil += w.recoil; if (p.human) p.punch += w.recoil * .0045f; }
    float sp = gun ? spreadOf(p) + extra : 0;
    V3 d = fwdv(p.yaw + rndr(-1, 1) * sp, p.pitch + p.punch + rndr(-1, 1) * sp);
    float range = w.range, best = map.rayWorld(o, d, range), t; int hit = -1; bool head = false;
    for (int j = 0; j < 10; j++) {
      Player& e = pl[j]; if (!e.alive || e.team == p.team) continue;
      if (rayAABB(o, d, e.pos.x - .32f, e.pos.y, e.pos.z - .32f, e.pos.x + .32f, e.pos.y + 1.5f, e.pos.z + .32f, t) && t < best) { best = t; hit = j; head = false; }
      if (gun && rayAABB(o, d, e.pos.x - .2f, e.pos.y + 1.5f, e.pos.z - .2f, e.pos.x + .2f, e.pos.y + 1.85f, e.pos.z + .2f, t) && t < best) { best = t; hit = j; head = true; }
    }
    V3 hp = o + d * std::min(best, range);
    if (gun) { V3 r = {cosf(p.yaw), 0, sinf(p.yaw)}; tracers.push_back({o + d * .7f + r * .14f + V3{0, -.12f, 0}, hp, .07f}); }
    if (hit >= 0) { float dmg = w.dmg * (head ? 3.5f : 1.f) * (1.f - std::min(best, 80.f) / 260.f); spark(hp, 5, .7f, .05f, .05f); hurt(hit, dmg, i, head, p.cur); }
    else if (best < range) spark(hp, 4, .7f, .7f, .65f);
  }
  void tryFire(Player& p, float extra) {
    if (p.fireCd > 0 || p.reloading) return;
    if (WD[p.cur].mag > 0 && p.mag[p.cur] <= 0) { startReload(p); return; }
    fireShot(p, extra);
  }

  // ---- bots
  V3 lookTarget(const Player& b) const { if (bomb == B_PLANTED) return bombPos; if (b.team == TEAM_CT) return V3{0, 0, 8}; return map.siteC[tSite]; }
  void botScan(Player& b) {
    V3 eye = eyeOf(b), f = fwdv(b.yaw, 0); int best = -1; float bd = 1e9f;
    for (int j = 0; j < 10; j++) {
      Player& e = pl[j]; if (!e.alive || e.team == b.team) continue;
      V3 tp = e.pos + V3{0, 1.3f, 0}, d = tp - eye; float L = len(d); if (L > 75) continue;
      if (!(dot(d * (1.f / L), f) > .35f || b.atkT > 0 || L < 6)) continue;
      if (!map.los(eye, tp)) continue; if (L < bd) { bd = L; best = j; }
    }
    if (best >= 0) {
      if (b.target != best) b.reactT = BOT_REACT[S->difficulty] * rndr(.7f, 1.3f); else if (!b.visible) b.reactT = BOT_REACT[S->difficulty] * .4f;
      b.target = best; b.visible = true; b.lostT = 0; b.lastSeen = pl[best].pos;
    } else { b.visible = false; if (b.target >= 0) b.lostT += .1f; }
  }
  int nearestBot(int team, V3 p) const {
    int bi = -1; float bd = 1e9f;
    for (int i = 0; i < 10; i++) if (botCtl(i) && pl[i].alive && pl[i].team == team) { float d = d2(pl[i].pos, p); if (d < bd) { bd = d; bi = i; } }
    return bi;
  }
  void botGoal(Player& b, int idx) {
    if (b.seenBomb != bomb) { b.seenBomb = bomb; b.holdT = 0; b.hasGoal = false; }
    bool need = !b.hasGoal || b.holdT <= 0;
    auto set = [&](V3 g, float hold) { b.goal = g; b.hasGoal = true; b.holdT = hold; };
    if (b.team == TEAM_T) {
      if (bomb == B_PLANTED) { if (need) set(pickSpot(bombPos, 4.f, 11.f, &bombPos), rndr(5, 10)); }
      else if (b.hasBomb) { set(plantSpot, 1.f); if (siteAt(b.pos) >= 0 && d2(b.pos, plantSpot) < 1.6f && b.onGround) b.useHeld = true; }
      else if (bomb == B_DROPPED && nearestBot(TEAM_T, bombPos) == idx) set(bombPos, 1.f);
      else if (need) { int s = rnd() < .8f ? tSite : 1 - tSite; set(pickSpot(map.siteC[s], 3.f, 9.f, nullptr), rndr(8, 14)); }
    } else {
      if (bomb == B_PLANTED) {
        if (idx == defIdx) { set(bombPos, 1.f); if (d2(b.pos, bombPos) < 2.0f) b.useHeld = true; }
        else if (need) set(pickSpot(bombPos, 5.f, 10.f, &bombPos), rndr(6, 12));
      } else if (need) { int s = b.slot == 4 ? rndi(2) : b.slot % 2; set(pickSpot(map.siteC[s], 4.f, 12.f, nullptr), rndr(8, 16)); }
    }
  }
  void botFollow(Player& b, float dt, float spd) {
    if (!b.hasGoal) return;
    if (d2(b.pos, b.goal) < 1.2f) { b.path.clear(); b.holdT -= dt; V3 lt = lookTarget(b); float ty = atan2f(lt.x - b.pos.x, -(lt.z - b.pos.z)); b.yaw += clampf(angDiff(b.yaw, ty), -2 * dt, 2 * dt); return; }
    b.repathT -= dt;
    if (b.path.empty() || b.repathT <= 0 || d2(b.goal, b.pathGoal) > 2) { map.findPath(b.pos, b.goal, b.path); b.pathIdx = 0; b.pathGoal = b.goal; b.repathT = rndr(2, 4); }
    if (b.path.empty()) return;
    int n = (int)b.path.size();
    while (b.pathIdx + 1 < n && map.lineFree(b.pos.x, b.pos.z, b.path[b.pathIdx + 1].x, b.path[b.pathIdx + 1].z, .5f)) b.pathIdx++;
    V3 t = b.path[std::min(b.pathIdx, n - 1)]; float dx = t.x - b.pos.x, dz = t.z - b.pos.z, L = sqrtf(dx * dx + dz * dz);
    if (L < .6f) { if (b.pathIdx < n - 1) b.pathIdx++; else b.holdT -= dt; return; }
    moveXZ(b, dx / L * spd * dt, dz / L * spd * dt);
    float ty = atan2f(dx, -dz); b.yaw += clampf(angDiff(b.yaw, ty), -9 * dt, 9 * dt); b.pitch -= b.pitch * std::min(1.f, 5 * dt);
    b.stuckT += dt;
    if (b.stuckT >= .6f) { if (len(b.pos - b.lastPos) < .25f) { b.path.clear(); b.repathT = 0; float a = rnd() * 6.28f; moveXZ(b, cosf(a) * .5f, sinf(a) * .5f); } b.lastPos = b.pos; b.stuckT = 0; }
  }
  void botUpdate(Player& b, int idx, float dt, bool act) {
    int df = S->difficulty; b.useHeld = false; V3 before = b.pos;
    if (!act || b.startDelay > 0) { if (act) b.startDelay -= dt; physicsY(b, dt); b.speedNow = 0; return; }
    b.scanT -= dt; if (b.scanT <= 0) { b.scanT = .1f; botScan(b); }
    float spd = 4.9f * WD[b.cur].speed;
    if (b.target >= 0 && b.visible && pl[b.target].alive) {
      Player& e = pl[b.target]; V3 eye = eyeOf(b), tp = e.pos + V3{0, df == 2 ? 1.5f : 1.3f, 0}, d = tp - eye;
      float hd = sqrtf(d.x * d.x + d.z * d.z), ty = atan2f(d.x, -d.z), tpch = atan2f(d.y, hd), rate = BOT_TURN[df] * dt;
      b.yaw += clampf(angDiff(b.yaw, ty), -rate, rate); b.pitch += clampf(tpch - b.pitch, -rate, rate);
      b.reactT -= dt; b.scoped = (b.cur == W_SNIPER);
      b.strafeT -= dt; if (b.strafeT <= 0) { b.strafeT = rndr(.35f, 1.1f); float r = rnd(); b.strafeDir = r < .35f ? -1.f : (r < .7f ? 1.f : 0.f); }
      moveXZ(b, cosf(b.yaw) * b.strafeDir * spd * .55f * dt, sinf(b.yaw) * b.strafeDir * spd * .55f * dt);
      float ang = fabsf(angDiff(b.yaw, ty));
      if (b.reactT <= 0 && ang < .1f) {
        if (WD[b.cur].mag > 0 && b.mag[b.cur] == 0) startReload(b);
        else if (b.fireCd <= 0 && !b.reloading) {
          bool ok = true;
          if (WD[b.cur].autof) { if (b.burstWait > 0) { b.burstWait -= dt; ok = false; } else if (b.burst <= 0) b.burst = 2 + rndi(6); }
          if (ok) { float extra = BOT_AIM[df] * (1 + len(d) / 35.f) + (b.strafeDir != 0 ? .012f : 0.f); fireShot(b, extra); if (WD[b.cur].autof && --b.burst <= 0) b.burstWait = rndr(.2f, .6f); }
        }
      }
    } else {
      b.scoped = false;
      if (b.target >= 0 && b.lostT > .5f) { b.chaseT = rndr(2, 4); b.target = -1; b.goal = b.lastSeen; b.hasGoal = true; b.path.clear(); }
      if (WD[b.cur].mag > 0 && b.mag[b.cur] < WD[b.cur].mag * .4f && !b.reloading) startReload(b);
      if (b.chaseT > 0) { b.chaseT -= dt; b.goal = b.lastSeen; b.hasGoal = true; } else botGoal(b, idx);
      if (!b.useHeld) botFollow(b, dt, spd);
    }
    physicsY(b, dt); b.speedNow = d2(b.pos, before) / dt;
  }

  // ---- human
  void humanUpdate(Player& p, float dt, const Input& in, bool act) {
    float sm = p.scoped ? S->adsSens : 1.f;
    p.yaw += in.lookX * S->sens * sm; p.pitch = clampf(p.pitch + in.lookY * (S->invertY ? -1.f : 1.f) * S->sens * sm, -1.45f, 1.45f);
    if (in.slot >= 0) { int w = slotWeapon(p, in.slot); if (w >= 0) selectWeapon(p, w); }
    if (in.scope && p.cur == W_SNIPER && !p.reloading) p.scoped = !p.scoped;
    if (p.cur != W_SNIPER || p.reloading) p.scoped = false;
    p.useHeld = in.use && act; bool busy = p.useHeld && useMode(p) != 0; V3 before = p.pos;
    bool canMove = phase != PH_FREEZE && phase != PH_END;
    if (canMove && !busy) {
      float mx = in.mx, my = in.my, l = sqrtf(mx * mx + my * my); if (l > 1) { mx /= l; my /= l; }
      float sp = 5.4f * WD[p.cur].speed * (p.scoped ? .7f : 1.f); V3 f = fwdv(p.yaw, 0), r = {cosf(p.yaw), 0, sinf(p.yaw)};
      moveXZ(p, (f.x * my + r.x * mx) * sp * dt, (f.z * my + r.z * mx) * sp * dt);
      if (in.jump && p.onGround) { p.vy = 6.4f; p.onGround = false; }
    }
    physicsY(p, dt); p.speedNow = d2(p.pos, before) / dt;
    if (in.reload) startReload(p);
    if (act && !busy) { bool want = WD[p.cur].autof ? in.fire : (in.firePressed || (in.fire && WD[p.cur].mag == 0)); if (want) tryFire(p, 0); }
  }

  // ---- round flow
  void endRound(int winner, const char* why) {
    if (phase != PH_LIVE) return; phase = PH_POST; phaseT = 5.5f; score[winner]++; lastWinner = winner;
    announce(winner == humanTeam ? "ROUND WON" : "ROUND LOST", why, 5.f);
    for (auto& p : pl) p.money = std::min(16000, p.money + (p.team == winner ? 3250 : 1900));
    if (score[winner] >= roundsToWin) { matchOver = true; humanWonMatch = (winner == humanTeam); statsDirty = true; if (S) { if (humanWonMatch) S->wins++; else S->losses++; } }
  }
  void explode() {
    bomb = B_EXPLODED; explodeT = 0; statBlasts++;
    for (int i = 0; i < 10; i++) if (pl[i].alive) { float d = d2(pl[i].pos, bombPos); if (d < 14) hurt(i, 999, -1, false, W_C4); else if (d < 22) hurt(i, 60, -1, false, W_C4); }
    endRound(TEAM_T, "THE BOMB DETONATED");
  }
  void bombLogic(float dt) {
    int pn = -1, dn = -1;
    for (int i = 0; i < 10; i++) if (pl[i].alive && pl[i].useHeld) { int m = useMode(pl[i]); if (m == 1 && pn < 0) pn = i; if (m == 2 && dn < 0) dn = i; }
    if (pn >= 0) { plantP += dt; if (plantP >= 3.2f) { bomb = B_PLANTED; bombPos = pl[pn].pos; bombT = 40.f; pl[pn].hasBomb = false; pl[pn].money += 300; plantP = 0; statPlants++; announce("BOMB PLANTED", "40 SECONDS TO DEFUSE", 3.f); } } else plantP = 0;
    if (dn >= 0) { defuseP += dt / (pl[dn].kit ? 5.f : 10.f); if (defuseP >= 1.f) { bomb = B_DEFUSED; pl[dn].money += 300; statDefuses++; endRound(TEAM_CT, "THE BOMB HAS BEEN DEFUSED"); return; } } else defuseP = 0;
    if (bomb == B_DROPPED) for (int i = 0; i < 10; i++) if (pl[i].alive && pl[i].team == TEAM_T && d2(pl[i].pos, bombPos) < 1.3f) { pl[i].hasBomb = true; bomb = B_CARRIED; if (i == 0) announce("YOU PICKED UP THE BOMB", "", 2.f); break; }
    if (bomb == B_PLANTED) { bombT -= dt; if (bombT <= 0) explode(); }
  }
  void checkEnd() {
    int aT = 0, aC = 0; for (auto& p : pl) if (p.alive) (p.team == TEAM_T ? aT : aC)++;
    if (aC == 0) endRound(TEAM_T, "COUNTER-TERRORISTS ELIMINATED");
    else if (aT == 0 && bomb != B_PLANTED) endRound(TEAM_CT, "TERRORISTS ELIMINATED");
    else if (phaseT <= 0 && bomb != B_PLANTED) endRound(TEAM_CT, "TIME RAN OUT");
  }

  void update(float dt, const Input& in) {
    dt = std::min(dt, .05f); clock += dt;
    for (auto& t : tracers) t.life -= dt; tracers.erase(std::remove_if(tracers.begin(), tracers.end(), [](const Tracer& t) { return t.life <= 0; }), tracers.end());
    for (auto& s : sparks) { s.p = s.p + s.v * dt; s.v.y -= 9 * dt; if (s.p.y < .03f) { s.p.y = .03f; s.v = s.v * .2f; } s.life -= dt; }
    sparks.erase(std::remove_if(sparks.begin(), sparks.end(), [](const Spark& s) { return s.life <= 0; }), sparks.end());
    for (auto& f : feed) f.life -= dt; feed.erase(std::remove_if(feed.begin(), feed.end(), [](const Feed& f) { return f.life <= 0; }), feed.end());
    msgT -= dt; hitFlash -= dt; hitFromT -= dt; hitMarker -= dt; if (explodeT >= 0) explodeT += dt;
    if (phase == PH_END) return;
    if (phase == PH_FREEZE) { phaseT -= dt; if (phaseT <= 0) { phase = PH_LIVE; phaseT = 115.f; announce("GO GO GO", "", 1.5f); } }
    else if (phase == PH_LIVE) { roundElapsed += dt; if (bomb != B_PLANTED) phaseT -= dt; }
    else if (phase == PH_POST) { phaseT -= dt; if (phaseT <= 0) { if (matchOver) phase = PH_END; else { round++; startRound(false); } return; } }
    bool act = phase == PH_LIVE;
    defIdx = bomb == B_PLANTED ? nearestBot(TEAM_CT, bombPos) : -1;
    for (int i = 0; i < 10; i++) {
      Player& p = pl[i];
      if (!p.alive) { p.deadT += dt; continue; }
      tick(p, dt);
      if (botCtl(i)) botUpdate(p, i, dt, act); else humanUpdate(p, dt, in, act);
    }
    for (int i = 0; i < 10; i++) for (int j = i + 1; j < 10; j++) {
      Player &a = pl[i], &b = pl[j]; if (!a.alive || !b.alive || fabsf(a.pos.y - b.pos.y) > 1.f) continue;
      float dx = b.pos.x - a.pos.x, dz = b.pos.z - a.pos.z, d = sqrtf(dx * dx + dz * dz);
      if (d < .8f) { if (d < .01f) { dx = rndr(-1, 1); dz = 1; d = 1; } float k = (.8f - d) * .5f / d; if (botCtl(i)) moveXZ(a, -dx * k, -dz * k); if (botCtl(j)) moveXZ(b, dx * k, dz * k); }
    }
    specT -= dt;
    if (specT <= 0) {
      specT = .15f;
      for (auto& e : pl) { e.spotted = false; if (e.team == humanTeam || !e.alive) continue; V3 c = e.pos + V3{0, 1.3f, 0};
        for (auto& t : pl) if (t.alive && t.team == humanTeam && d2(t.pos, e.pos) < 70 && map.los(eyeOf(t), c)) { e.spotted = true; break; } }
    }
    if (!pl[0].alive) { if (spec < 0 || !pl[spec].alive) { spec = -1; for (int i = 1; i < 10 && spec < 0; i++) if (pl[i].alive && pl[i].team == humanTeam) spec = i; for (int i = 1; i < 10 && spec < 0; i++) if (pl[i].alive) spec = i; } } else spec = -1;
    if (act) { bombLogic(dt); if (phase == PH_LIVE) checkEnd(); }
  }
};
