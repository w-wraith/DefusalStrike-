// DEFUSAL STRIKE - touch controls, HUD, menus, settings (platform independent)
#pragma once
#include "render.h"

enum { B_FIRE, B_FIRE2, B_JUMP, B_RELOAD, B_USE, B_SCOPE, B_BUY, B_PAUSE, B_S0, B_S1, B_S2, B_N };
struct BtnDef { float x, y, r; const char* lab; bool vis; };
enum { M_MENU, M_SIDE, M_HOW, M_SET, M_GAME };

static void layoutBtns(float W, float H, const Settings& S, const Game& G, BtnDef* b) {
  float h = S.hudScale; const Player& p = G.pl[0];
  b[B_FIRE] = {W - 136, H - 150, 74 * h, "FIRE", p.alive};
  b[B_FIRE2] = {100, 300, 46 * h, "FIRE", p.alive && S.leftFire};
  b[B_JUMP] = {W - 290, H - 80, 46 * h, "JUMP", p.alive};
  b[B_RELOAD] = {W - 300, H - 205, 42 * h, "RLD", p.alive};
  b[B_USE] = {W - 190, H - 295, 50 * h, G.useMode(p) == 1 ? "PLANT" : "DEFUSE", p.alive && G.useMode(p) != 0};
  b[B_SCOPE] = {W - 80, H - 295, 40 * h, "SCOPE", p.alive && p.cur == W_SNIPER};
  b[B_BUY] = {W - 140, 46, 28 * h, "BUY", G.canBuy()};
  b[B_PAUSE] = {W - 56, 46, 28 * h, "II", true};
  b[B_S0] = {W / 2 - 70, H - 118, 30 * h, "KNF", p.alive};
  b[B_S1] = {W / 2, H - 118, 30 * h, "PST", p.alive};
  b[B_S2] = {W / 2 + 70, H - 118, 30 * h, "PRI", p.alive && G.slotWeapon(p, 2) >= 0};
}

struct Ptr { bool on = false; int id = -1; float x = 0, y = 0; int role = 0, btn = -1; float ox = 0, oy = 0; };
struct Controls {
  Ptr p[10]; bool down[B_N] = {}, pressed[B_N] = {}; float joyX = 0, joyY = 0, lookX = 0, lookY = 0, joyOX = 0, joyOY = 0, joyKX = 0, joyKY = 0; bool joyOn = false;
  bool uiDown = false, uiPressed = false, uiReleased = false; float uiX = 0, uiY = 0; int uiId = -1; bool playMode = false;
  void reset() { for (auto& q : p) q = Ptr(); memset(down, 0, sizeof down); memset(pressed, 0, sizeof pressed); joyX = joyY = lookX = lookY = 0; joyOn = false; }
  void joyUpdate(const Ptr& q, const Settings& S) {
    float R = 85 * S.joySize, dx = q.x - q.ox, dy = q.y - q.oy, l = sqrtf(dx * dx + dy * dy); if (l > R) { dx *= R / l; dy *= R / l; }
    joyKX = q.ox + dx; joyKY = q.oy + dy; joyX = dx / R; joyY = -dy / R; if (sqrtf(joyX * joyX + joyY * joyY) < .12f) joyX = joyY = 0;
  }
  void onEvent(int act, int id, float x, float y, const BtnDef* bt, float W, float H, const Settings& S) {
    if (act == 0 && !uiDown) { uiDown = true; uiId = id; uiX = x; uiY = y; uiPressed = true; }
    else if (uiDown && id == uiId) { uiX = x; uiY = y; if (act == 2) { uiDown = false; uiReleased = true; } }
    if (!playMode) return;
    int k = -1; for (int i = 0; i < 10; i++) if (p[i].on && p[i].id == id) k = i;
    if (act == 0) {
      if (k < 0) for (int i = 0; i < 10; i++) if (!p[i].on) { k = i; break; }
      if (k < 0) return; Ptr& q = p[k]; q = Ptr(); q.on = true; q.id = id; q.x = x; q.y = y;
      for (int b = 0; b < B_N; b++) if (bt[b].vis) { float dx = x - bt[b].x, dy = y - bt[b].y, r = bt[b].r * 1.15f; if (dx * dx + dy * dy < r * r) { q.role = 3; q.btn = b; down[b] = true; pressed[b] = true; return; } }
      if (x < W * .38f && y > H * .2f) { q.role = 1; q.ox = S.fixedJoy ? 150.f : x; q.oy = S.fixedJoy ? H - 150.f : y; joyOn = true; joyOX = q.ox; joyOY = q.oy; joyUpdate(q, S); }
      else q.role = 2;
    } else if (k >= 0) {
      Ptr& q = p[k];
      if (act == 1) { if (q.role == 2) { lookX += x - q.x; lookY += y - q.y; } q.x = x; q.y = y; if (q.role == 1) joyUpdate(q, S); }
      else { if (q.role == 3) down[q.btn] = false; if (q.role == 1) { joyOn = false; joyX = joyY = 0; } q.on = false; }
    }
  }
  void frameEnd() { uiPressed = false; uiReleased = false; memset(pressed, 0, sizeof pressed); lookX = lookY = 0; }
};

struct App {
  Gfx g; Controls c; Settings S; Game game; int mode = M_MENU, setFrom = M_MENU, tab = 0, uiActive = -1;
  bool paused = false, buyOpen = false, back = false, quit = false, saveReq = false; float t = 0, fps = 60; BtnDef btns[B_N];
  bool playing() const { return mode == M_GAME && !paused && !buyOpen && game.phase != PH_END; }
};

// ------------------------------------------------------------------ widgets
static const float RH = 54;
struct UIx {
  Gfx& g; Controls& c; int& active; int id = 0;
  bool inside(float x, float y, float w, float h) const { return c.uiX >= x && c.uiX <= x + w && c.uiY >= y && c.uiY <= y + h; }
  bool button(float x, float y, float w, float h, const char* t, float sc = 3, int st = 0) {
    bool hov = c.uiDown && inside(x, y, w, h); float k = hov ? 1.25f : 1.f; float r = .12f, gg = .14f, b = .18f, a = .9f;
    if (st == 1) { r = .95f; gg = .55f; b = .1f; } else if (st == 2) { r = .6f; gg = .15f; b = .15f; } else if (st == 3) { r = .15f; gg = .15f; b = .15f; a = .6f; } else if (st == 4) { r = .15f; gg = .3f; b = .65f; } else if (st == 5) { r = .8f; gg = .5f; b = .15f; }
    g.rect(x, y, w, h, std::min(1.f, r * k), std::min(1.f, gg * k), std::min(1.f, b * k), a); g.rect(x, y, w, 2, 1, 1, 1, .25f); g.rect(x, y + h - 2, w, 2, 0, 0, 0, .4f);
    g.text(t, x + w / 2, y + h / 2 - 3.5f * sc, sc, st == 3 ? .5f : 1, st == 3 ? .5f : 1, st == 3 ? .5f : 1, 1, 1);
    return st != 3 && c.uiPressed && inside(x, y, w, h);
  }
  void row(float x, float y, float w, const char* lab) { g.rect(x, y, w, RH - 6, .1f, .11f, .14f, .85f); g.text(lab, x + 14, y + (RH - 6) / 2 - 7, 2, .9f, .92f, 1); }
  bool slider(const char* lab, float& v, float mn, float mx, float step, float x, float y, float w, const char* fmt = "%.1f") {
    int me = ++id; row(x, y, w, lab); float h = RH - 6, tx = x + w * .46f, tw = w * .38f, t = (v - mn) / (mx - mn);
    g.rect(tx, y + h / 2 - 3, tw, 6, .3f, .32f, .38f); g.rect(tx, y + h / 2 - 3, tw * t, 6, .95f, .55f, .1f); g.disc(tx + tw * t, y + h / 2, 11, 1, .8f, .4f);
    char b[24]; snprintf(b, 24, fmt, v); g.text(b, x + w - 14, y + h / 2 - 7, 2, 1, 1, 1, 1, 2);
    bool ch = false; if (c.uiPressed && inside(tx - 20, y, tw + 40, h)) active = me;
    if (active == me && c.uiDown) { float nv = mn + clampf((c.uiX - tx) / tw, 0, 1) * (mx - mn); if (step > 0) nv = roundf(nv / step) * step; nv = clampf(nv, mn, mx); if (nv != v) { v = nv; ch = true; } }
    return ch;
  }
  bool slideri(const char* lab, int& v, int mn, int mx, int step, float x, float y, float w) { float f = (float)v; bool ch = slider(lab, f, (float)mn, (float)mx, (float)step, x, y, w, "%.0f"); v = (int)f; return ch; }
  bool toggle(const char* lab, int& v, float x, float y, float w) {
    row(x, y, w, lab); float h = RH - 6; bool on = v != 0; g.rect(x + w - 104, y + 6, 90, h - 12, on ? .2f : .25f, on ? .65f : .25f, on ? .25f : .28f); g.text(on ? "ON" : "OFF", x + w - 59, y + h / 2 - 7, 2, 1, 1, 1, 1, 1);
    if (c.uiPressed && inside(x, y, w, h)) { v = !v; return true; } return false;
  }
  bool choice(const char* lab, int& v, const char* const* names, int n, float x, float y, float w) {
    row(x, y, w, lab); float h = RH - 6; g.rect(x + w * .46f, y + 6, w * .54f - 14, h - 12, .2f, .22f, .28f); g.text(names[v], x + w * .46f + (w * .54f - 14) / 2, y + h / 2 - 7, 2, 1, .8f, .4f, 1, 1);
    g.text("<", x + w * .46f + 10, y + h / 2 - 7, 2, .7f, .7f, .7f); g.text(">", x + w - 24, y + h / 2 - 7, 2, .7f, .7f, .7f);
    if (c.uiPressed && inside(x, y, w, h)) { v = (v + 1) % n; return true; } return false;
  }
};

// ------------------------------------------------------------------ HUD pieces
static const float CHCOL[6][3] = {{.2f, 1, .2f}, {1, 1, 1}, {1, .2f, .2f}, {.1f, .9f, 1}, {1, .95f, .2f}, {1, .4f, .8f}};
static void drawCrosshair(Gfx& g, const Settings& S, float cx, float cy, float spreadPx) {
  const float* col = CHCOL[S.chColor % 6]; float gap = S.chGap + (S.chDynamic ? spreadPx : 0), sz = S.chSize, th = S.chThick, a = S.chAlpha;
  for (int pass = S.chOutline ? 0 : 1; pass < 2; pass++) {
    float o = pass == 0 ? 1.f : 0.f, r = pass ? col[0] : 0, gg = pass ? col[1] : 0, b = pass ? col[2] : 0, al = pass ? a : a * .8f;
    auto R = [&](float x, float y, float w, float h) { g.rect(x - o, y - o, w + 2 * o, h + 2 * o, r, gg, b, al); };
    if (S.chStyle == 0 || S.chStyle == 3) { R(cx - th / 2, cy + gap, th, sz); R(cx - gap - sz, cy - th / 2, sz, th); R(cx + gap, cy - th / 2, sz, th); if (S.chStyle == 0) R(cx - th / 2, cy - gap - sz, th, sz); }
    if (S.chStyle == 1) R(cx - th, cy - th, th * 2, th * 2);
    if (S.chStyle == 2) g.ring(cx, cy, gap + sz * .5f - th / 2 - o, gap + sz * .5f + th / 2 + o, r, gg, b, al);
    if (S.chDot && S.chStyle != 1) R(cx - th / 2, cy - th / 2, th, th);
  }
}
static void fmtTime(char* b, int sec) { if (sec < 0) sec = 0; snprintf(b, 16, "%d:%02d", sec / 60, sec % 60); }

static void drawMinimap(Gfx& g, const Game& G, const Settings& S, float t) {
  float hs = S.hudScale, ms = 170 * S.minimapSize * hs, ox = 14, oy = 14; g.rect(ox, oy, ms, ms, 0, 0, 0, .45f);
  auto X = [&](float x) { return ox + (x + 40) / 80 * ms; }; auto Z = [&](float z) { return oy + (z + 40) / 80 * ms; };
  for (auto& b : G.map.solids) g.rect(X(b.x0), Z(b.z0), (b.x1 - b.x0) / 80 * ms, (b.z1 - b.z0) / 80 * ms, .6f, .6f, .62f, .85f);
  for (int s = 0; s < 2; s++) g.text(s ? "B" : "A", X(G.map.siteC[s].x), Z(G.map.siteC[s].z + 6) - 7 * hs, 2 * hs, 1, .85f, .3f, 1, 1);
  if (G.bomb == B_PLANTED) g.disc(X(G.bombPos.x), Z(G.bombPos.z), (4 + 2 * sinf(t * 8)) * hs, 1, .1f, .1f);
  if (G.bomb == B_DROPPED) g.disc(X(G.bombPos.x), Z(G.bombPos.z), 4 * hs, 1, .9f, .1f);
  for (int i = 1; i < 10; i++) { const Player& p = G.pl[i]; if (!p.alive) continue; bool mine = p.team == G.humanTeam; if (!mine && !p.spotted) continue;
    if (mine) g.disc(X(p.pos.x), Z(p.pos.z), 3.5f * hs, .3f, .8f, 1, 1, 10); else g.disc(X(p.pos.x), Z(p.pos.z), 3.5f * hs, 1, .2f, .2f, 1, 10); }
  const Player& h = G.pl[0]; if (h.alive) { float x = X(h.pos.x), z = Z(h.pos.z), s = sinf(h.yaw), c = -cosf(h.yaw), k = 6 * hs;
    g.tri(x + s * k, z + c * k, x - s * k * .6f - c * k * .6f, z - c * k * .6f + s * k * .6f, x - s * k * .6f + c * k * .6f, z - c * k * .6f - s * k * .6f, 1, 1, 1); }
}

static void drawHUD(App& a, float W, float H) {
  Gfx& g = a.g; Game& G = a.game; const Settings& S = a.S; Player& h = G.pl[0]; float hs = S.hudScale, cx = W / 2; char b[96];
  int vi = h.alive ? 0 : (G.spec >= 0 ? G.spec : 0); const Player& v = G.pl[vi];
  // top scoreboard
  float pw = 150 * hs; g.rect(cx - pw, 8, pw * 2, 46 * hs, 0, 0, 0, .5f);
  int sc[2] = {G.score[TEAM_T], G.score[TEAM_CT]}; snprintf(b, 96, "%d", sc[0]); g.text(b, cx - pw * .72f, 16 * hs, 4 * hs, 1, .7f, .25f, 1, 1);
  snprintf(b, 96, "%d", sc[1]); g.text(b, cx + pw * .72f, 16 * hs, 4 * hs, .4f, .65f, 1, 1, 1);
  if (G.bomb == B_PLANTED) fmtTime(b, (int)ceilf(G.bombT)), g.text(b, cx, 16 * hs, 3.5f * hs, 1, .2f, .2f, 1, 1); else fmtTime(b, (int)ceilf(G.phaseT)), g.text(b, cx, 16 * hs, 3.5f * hs, 1, 1, 1, 1, 1);
  for (int t = 0; t < 2; t++) { int n = 0; for (auto& p : G.pl) if (p.team == t && p.alive) n++;
    for (int i = 0; i < 5; i++) g.rect(t == 0 ? cx - pw + 8 + i * 12 * hs : cx + pw - 8 - (5 - i) * 12 * hs, 56 * hs, 9 * hs, 5 * hs, t == 0 ? 1.f : .4f, t == 0 ? .7f : .65f, t == 0 ? .25f : 1.f, i < n ? 1.f : .25f); }
  float iy = 70 * hs;
  if (G.bomb == B_PLANTED) g.text("BOMB PLANTED", cx, iy, 2.5f * hs, 1, .2f + .3f * sinf(a.t * 8), .2f, 1, 1);
  else if (G.bomb == B_DROPPED) g.text("BOMB DROPPED", cx, iy, 2 * hs, 1, .9f, .2f, 1, 1);
  else if (h.hasBomb && h.alive) g.text("YOU HAVE THE BOMB", cx, iy, 2 * hs, 1, .9f, .2f, 1, 1);
  if (S.minimap) { drawMinimap(g, G, S, a.t); g.text(("$" + std::to_string(h.money)).c_str(), 16, 14 + 176 * S.minimapSize * hs, 2.5f * hs, .5f, 1, .5f); }
  // kill feed
  if (S.killfeed) { float y = 90; for (auto& f : G.feed) { float w = Gfx::textW(f.t.c_str(), 2 * hs); g.rect(W - 20 - w - 8, y - 3, w + 16, 20 * hs, f.me ? .8f : 0, f.me ? .2f : 0, 0, .5f); g.text(f.t.c_str(), W - 24, y, 2 * hs, f.team == TEAM_T ? 1.f : .5f, f.team == TEAM_T ? .75f : .75f, f.team == TEAM_T ? .35f : 1.f, 1, 2); y += 24 * hs; } }
  // bottom strip
  float by = H - 54;
  if (h.alive) {
    g.rect(cx - 230 * hs, by, 460 * hs, 44 * hs, 0, 0, 0, .55f); snprintf(b, 96, "HP %d", h.hp); g.text(b, cx - 215 * hs, by + 12 * hs, 3 * hs, h.hp > 35 ? .4f : 1.f, h.hp > 35 ? 1.f : .3f, .3f);
    snprintf(b, 96, "AR %d", h.armor); g.text(b, cx - 80 * hs, by + 12 * hs, 3 * hs, .5f, .75f, 1);
    if (WD[h.cur].mag > 0) snprintf(b, 96, "%d/%d", h.mag[h.cur], h.res[h.cur]); else snprintf(b, 96, "%s", WD[h.cur].name);
    g.text(b, cx + 225 * hs, by + 12 * hs, 3 * hs, h.reloading ? 1.f : 1.f, h.reloading ? .6f : 1.f, h.reloading ? .2f : 1.f, 1, 2);
    if (h.reloading) g.text("RELOADING", cx + 225 * hs, by - 18 * hs, 2 * hs, 1, .6f, .2f, 1, 2);
    if (h.kit) g.text("KIT", cx + 30 * hs, by + 14 * hs, 2 * hs, .5f, 1, .5f);
  } else {
    g.text("YOU DIED", cx, H * .62f, 5, 1, .3f, .3f, 1, 1); snprintf(b, 96, "SPECTATING %s", v.name); g.text(b, cx, H * .62f + 50, 2.5f, 1, 1, 1, 1, 1);
  }
  // crosshair / scope
  if (h.alive) {
    if (h.scoped) { g.ring(cx, H / 2, H * .46f, H * .95f, 0, 0, 0, 1, 48); g.rect(0, H / 2 - 1, W, 2, 0, 0, 0, .8f); g.rect(cx - 1, 0, 2, H, 0, 0, 0, .8f); g.disc(cx, H / 2, 2.5f, 1, .1f, .1f); }
    else { float f = h.scoped ? 26.f : S.fov, pxr = G.spreadOf(h) * (H * .5f / tanf(f * PI / 360.f)); drawCrosshair(g, S, cx, H / 2, pxr); }
    if (G.hitMarker > 0) { for (int s = -1; s <= 1; s += 2) { g.line(cx + s * 6, H / 2 - 6, cx + s * 14, H / 2 - 14, 2, 1, 1, 1); g.line(cx + s * 6, H / 2 + 6, cx + s * 14, H / 2 + 14, 2, 1, 1, 1); } }
  }
  // damage
  if (S.dmgInd && G.hitFlash > 0) { g.rect(0, 0, W, H, 1, 0, 0, std::min(.3f, G.hitFlash * .4f));
    if (G.hitFromT > 0 && h.alive) { float ang = angDiff(h.yaw, atan2f(G.hitFrom.x - h.pos.x, -(G.hitFrom.z - h.pos.z))), R = 170, s = sinf(ang), c = cosf(ang);
      float tx = cx + s * (R + 26), ty = H / 2 - c * (R + 26), bx = cx + s * R, by2 = H / 2 - c * R; g.tri(tx, ty, bx - c * 16, by2 - s * 16, bx + c * 16, by2 + s * 16, 1, .1f, .1f, std::min(1.f, G.hitFromT)); } }
  // progress bars
  if (G.plantP > 0 || G.defuseP > 0) { float pr = G.plantP > 0 ? G.plantP / 3.2f : G.defuseP; g.rect(cx - 150, H * .66f, 300, 18, 0, 0, 0, .6f); g.rect(cx - 148, H * .66f + 2, 296 * pr, 14, 1, .6f, .1f); g.text(G.plantP > 0 ? "PLANTING" : "DEFUSING", cx, H * .66f - 22, 2.5f, 1, 1, 1, 1, 1); }
  if (G.msgT > 0) { g.text(G.msg.c_str(), cx, H * .2f, 6, 1, .85f, .3f, std::min(1.f, G.msgT), 1); g.text(G.msg2.c_str(), cx, H * .2f + 56, 3, 1, 1, 1, std::min(1.f, G.msgT), 1); }
  if (S.showFps) { snprintf(b, 96, "FPS %d", (int)a.fps); g.text(b, 14, H - 24, 2, .8f, 1, .8f); }
  // touch controls
  if (h.alive) {
    float op = S.btnOpacity; if (a.c.joyOn || S.fixedJoy) { float ox = a.c.joyOn ? a.c.joyOX : 150, oy = a.c.joyOn ? a.c.joyOY : H - 150, kx = a.c.joyOn ? a.c.joyKX : ox, ky = a.c.joyOn ? a.c.joyKY : oy, R = 85 * S.joySize;
      g.ring(ox, oy, R - 3, R, 1, 1, 1, op * .8f); g.disc(kx, ky, 34 * S.joySize, 1, 1, 1, op * .7f); }
    for (int i = 0; i < B_N; i++) { const BtnDef& d = a.btns[i]; if (!d.vis) continue; bool dn = a.c.down[i]; bool hot = i == B_USE; float pulse = hot ? .3f + .2f * sinf(a.t * 8) : 0;
      bool cur = (i == B_S0 && h.cur == W_KNIFE) || (i == B_S1 && h.cur == W_PISTOL) || (i == B_S2 && h.cur >= W_SMG && h.cur <= W_SNIPER);
      g.disc(d.x, d.y, d.r, hot ? 1.f : cur ? 1.f : 1.f, hot ? .6f : cur ? .6f : 1.f, hot ? .1f : cur ? .1f : 1.f, op * (dn ? .9f : (hot || cur) ? .55f + pulse : .3f));
      g.ring(d.x, d.y, d.r - 2, d.r, 1, 1, 1, op); g.text(d.lab, d.x, d.y - 3.5f * 2 * hs, 2 * hs, 1, 1, 1, std::min(1.f, op + .3f), 1); }
  }
}

// ------------------------------------------------------------------ screens
static void startGame(App& a, int team) { a.game.startMatch(team); a.mode = M_GAME; a.paused = false; a.buyOpen = false; a.c.reset(); }
static void dim(Gfx& g, float W, float H, float a) { g.rect(0, 0, W, H, 0, 0, 0, a); }

static void drawSettings(App& a, UIx& ui, float W, float H) {
  Gfx& g = a.g; Settings& S = a.S; static const char* TABS[6] = {"GRAPHICS", "VIEWMODEL", "CROSSHAIR", "HUD", "CONTROLS", "GAME"};
  float pw = std::min(W * .62f, 900.f), x = 30, y0 = 140, w = pw - 20; dim(g, pw + 40, H, .72f);
  g.text("SETTINGS", 30, 24, 4, 1, .6f, .1f);
  if (ui.button(pw - 150, 16, 170, 48, "BACK", 3, 2)) { a.mode = a.setFrom; a.saveReq = true; return; }
  for (int i = 0; i < 6; i++) if (ui.button(20 + i * (pw / 6), 76, pw / 6 - 4, 50, TABS[i], 2, a.tab == i ? 1 : 0)) a.tab = i;
  float y = y0; int id;
  switch (a.tab) {
    case 0: { static const char* FP[4] = {"30", "60", "90", "120"}; int fi = S.fpsCap == 30 ? 0 : S.fpsCap == 60 ? 1 : S.fpsCap == 90 ? 2 : 3;
      float rs = (float)S.renderScale; if (ui.slider("RENDER SCALE %", rs, 50, 100, 5, x, y, w, "%.0f")) S.renderScale = (int)rs; y += RH;
      if (ui.choice("FPS LIMIT", fi, FP, 4, x, y, w)) S.fpsCap = atoi(FP[fi]); y += RH;
      ui.toggle("DISTANCE FOG", S.fog, x, y, w); y += RH; ui.toggle("BLOB SHADOWS", S.blob, x, y, w); y += RH; ui.toggle("PARTICLES", S.particles, x, y, w); y += RH; ui.toggle("SHOW FPS", S.showFps, x, y, w); break; }
    case 1: ui.slider("FIELD OF VIEW", S.fov, 60, 110, 1, x, y, w, "%.0f"); y += RH; ui.slider("VIEWMODEL FOV", S.vmFov, 40, 90, 1, x, y, w, "%.0f"); y += RH;
      ui.slider("OFFSET X", S.vmX, -10, 10, 1, x, y, w, "%.0f"); y += RH; ui.slider("OFFSET Y", S.vmY, -10, 10, 1, x, y, w, "%.0f"); y += RH; ui.slider("OFFSET Z", S.vmZ, -10, 10, 1, x, y, w, "%.0f"); y += RH;
      ui.slider("WEAPON SCALE", S.vmScale, .6f, 1.4f, .05f, x, y, w, "%.2f"); y += RH; ui.toggle("WEAPON BOB", S.vmBob, x, y, w); y += RH; ui.toggle("LEFT HANDED", S.leftHand, x, y, w); break;
    case 2: { static const char* ST[4] = {"CROSS", "DOT", "CIRCLE", "T-SHAPE"}; static const char* CO[6] = {"GREEN", "WHITE", "RED", "CYAN", "YELLOW", "PINK"};
      ui.choice("STYLE", S.chStyle, ST, 4, x, y, w); y += RH; ui.choice("COLOR", S.chColor, CO, 6, x, y, w); y += RH; ui.slider("SIZE", S.chSize, 2, 30, 1, x, y, w, "%.0f"); y += RH;
      ui.slider("THICKNESS", S.chThick, 1, 6, 1, x, y, w, "%.0f"); y += RH; ui.slider("GAP", S.chGap, 0, 15, 1, x, y, w, "%.0f"); y += RH; ui.slider("OPACITY", S.chAlpha, .2f, 1, .05f, x, y, w, "%.2f"); y += RH;
      ui.toggle("OUTLINE", S.chOutline, x, y, w); y += RH; ui.toggle("CENTER DOT", S.chDot, x, y, w); y += RH; ui.toggle("DYNAMIC SPREAD", S.chDynamic, x, y, w);
      float px = pw + 80, py = 180; g.rect(px, py, W - px - 40, 300, .25f, .3f, .25f, .8f); float sp = S.chDynamic ? 6 + 6 * sinf(a.t * 2) : 0; drawCrosshair(g, S, px + (W - px - 40) / 2, py + 150, sp); g.text("PREVIEW", px + (W - px - 40) / 2, py + 310, 2, 1, 1, 1, 1, 1); break; }
    case 3: ui.slider("HUD SCALE", S.hudScale, .7f, 1.3f, .05f, x, y, w, "%.2f"); y += RH; ui.slider("BUTTON OPACITY", S.btnOpacity, .2f, 1, .05f, x, y, w, "%.2f"); y += RH;
      ui.toggle("MINIMAP", S.minimap, x, y, w); y += RH; ui.slider("MINIMAP SIZE", S.minimapSize, .6f, 1.5f, .05f, x, y, w, "%.2f"); y += RH; ui.toggle("KILL FEED", S.killfeed, x, y, w); y += RH;
      ui.toggle("DAMAGE INDICATOR", S.dmgInd, x, y, w); y += RH; ui.toggle("LEFT FIRE BUTTON", S.leftFire, x, y, w); break;
    case 4: ui.slider("LOOK SENSITIVITY", S.sens, .3f, 3, .05f, x, y, w, "%.2f"); y += RH; ui.slider("SCOPE SENSITIVITY", S.adsSens, .2f, 1.5f, .05f, x, y, w, "%.2f"); y += RH;
      ui.toggle("INVERT Y", S.invertY, x, y, w); y += RH; ui.slider("JOYSTICK SIZE", S.joySize, .7f, 1.5f, .05f, x, y, w, "%.2f"); y += RH; ui.toggle("FIXED JOYSTICK", S.fixedJoy, x, y, w); break;
    case 5: { static const char* DF[3] = {"EASY", "NORMAL", "HARD"}; ui.choice("BOT DIFFICULTY", S.difficulty, DF, 3, x, y, w); y += RH; ui.slideri("ROUNDS TO WIN", S.roundsToWin, 4, 12, 1, x, y, w); y += RH;
      g.text("DIFFICULTY AND ROUNDS APPLY TO THE NEXT MATCH", x, y + 6, 1.6f, .7f, .7f, .7f); y += 30;
      char b[64]; snprintf(b, 64, "MATCHES WON %d  LOST %d", S.wins, S.losses); g.text(b, x, y + 4, 2, 1, 1, 1); y += 36;
      if (ui.button(x, y, w / 2 - 6, 50, "RESET STATS", 2, 2)) { S.wins = S.losses = 0; }
      if (ui.button(x + w / 2 + 6, y, w / 2 - 6, 50, "RESET SETTINGS", 2, 2)) { int wn = S.wins, l = S.losses; S = Settings(); S.wins = wn; S.losses = l; } break; }
  }
  (void)id;
}

static void drawBuy(App& a, UIx& ui, float W, float H) {
  Gfx& g = a.g; Game& G = a.game; Player& h = G.pl[0]; float pw = 640, ph = 420, x = (W - pw) / 2, y = (H - ph) / 2; dim(g, W, H, .5f); g.rect(x, y, pw, ph, .06f, .07f, .09f, .95f);
  g.text("BUY MENU", x + 20, y + 16, 4, 1, .6f, .1f); char b[32]; snprintf(b, 32, "$%d", h.money); g.text(b, x + pw - 20, y + 20, 3.5f, .5f, 1, .5f, 1, 2);
  for (int i = 0; i < 5; i++) { float bx = x + 20 + (i % 2) * 310, by = y + 80 + (i / 2) * 84; char t[48]; snprintf(t, 48, "%s  $%d", BUY_NAME[i], BUY_COST[i]);
    bool owned = (i < 3 && h.have[W_SMG + i]) || (i == 3 && h.armor >= 100) || (i == 4 && (h.kit || h.team != TEAM_CT)); bool afford = h.money >= BUY_COST[i];
    if (ui.button(bx, by, 300, 72, t, 2.4f, owned || !afford ? 3 : 4)) G.buyItem(h, i); if (owned) g.text("OWNED", bx + 290, by + 6, 1.5f, .6f, 1, .6f, 1, 2); }
  if (ui.button(x + 20, y + ph - 80, pw - 40, 60, "CLOSE", 3, 2)) a.buyOpen = false;
}

static void menuScene(App& a) {
  float ang = a.t * .15f; V3 e = {cosf(ang) * 56, 24, sinf(ang) * 56}, d = V3{0, 0, 0} - e; float yaw = atan2f(d.x, -d.z), pit = atan2f(d.y, sqrtf(d.x * d.x + d.z * d.z));
  sceneRender(a.g, a.game, a.S, e, yaw, pit, a.S.fov, -1, (a.mode == M_SET && a.tab == 1) ? 2 : 0);
}

static void frameApp(App& a, float dt) {
  Gfx& g = a.g; Game& G = a.game; Settings& S = a.S; float W = g.VW, H = g.VH; a.t += dt; a.fps = a.fps * .95f + (1.f / std::max(dt, .0001f)) * .05f; g.T = a.t;
  UIx ui{g, a.c, a.uiActive}; layoutBtns(W, H, S, G, a.btns); if (!a.c.uiDown) a.uiActive = -1;
  if (a.mode == M_GAME) {
    bool back = a.back; a.back = false;
    if (back) { if (a.buyOpen) a.buyOpen = false; else if (G.phase != PH_END) { a.paused = !a.paused; a.c.reset(); } }
    bool over = a.paused || a.buyOpen || G.phase == PH_END; a.c.playMode = !over; Input in;
    if (!over) {
      Controls& c = a.c; in.mx = c.joyX; in.my = c.joyY; in.lookX = c.lookX * .0045f; in.lookY = c.lookY * .0045f; in.fire = c.down[B_FIRE] || c.down[B_FIRE2]; in.firePressed = c.pressed[B_FIRE] || c.pressed[B_FIRE2];
      in.jump = c.pressed[B_JUMP]; in.reload = c.pressed[B_RELOAD]; in.use = c.down[B_USE]; in.scope = c.pressed[B_SCOPE]; in.slot = c.pressed[B_S0] ? 0 : c.pressed[B_S1] ? 1 : c.pressed[B_S2] ? 2 : -1;
      if (c.pressed[B_PAUSE]) { a.paused = true; c.reset(); } else if (c.pressed[B_BUY] && G.canBuy()) { a.buyOpen = true; c.reset(); }
    }
    if (a.buyOpen && !G.canBuy()) a.buyOpen = false;
    if (!a.paused) G.update(dt, over ? Input() : in);
    if (G.statsDirty) { G.statsDirty = false; a.saveReq = true; }
    Player& h = G.pl[0]; int vi = h.alive ? 0 : (G.spec >= 0 ? G.spec : 0); const Player& v = G.pl[vi];
    float fov = (h.alive && h.scoped) ? 26.f : S.fov;
    sceneRender(g, G, S, Game::eyeOf(v), v.yaw, v.pitch + v.punch, fov, vi, (h.alive && vi == 0) ? 1 : 0);
    drawHUD(a, W, H);
    if (a.buyOpen) drawBuy(a, ui, W, H);
    if (a.paused) { dim(g, W, H, .6f); g.text("PAUSED", W / 2, 120, 7, 1, .6f, .1f, 1, 1); float bx = W / 2 - 180;
      if (ui.button(bx, 240, 360, 70, "RESUME", 3.5f, 1)) { a.paused = false; a.c.reset(); }
      if (ui.button(bx, 330, 360, 70, "SETTINGS", 3.5f)) { a.setFrom = M_GAME; a.mode = M_SET; }
      if (ui.button(bx, 420, 360, 70, "QUIT TO MENU", 3.5f, 2)) { a.mode = M_MENU; a.paused = false; a.saveReq = true; } }
    if (G.phase == PH_END) { dim(g, W, H, .65f); bool win = G.humanWonMatch; g.text(win ? "VICTORY" : "DEFEAT", W / 2, 110, 9, win ? .4f : 1.f, win ? 1.f : .3f, win ? .4f : .3f, 1, 1);
      char b[64]; snprintf(b, 64, "T %d  -  CT %d", G.score[TEAM_T], G.score[TEAM_CT]); g.text(b, W / 2, 220, 5, 1, 1, 1, 1, 1);
      snprintf(b, 64, "YOUR K/D %d/%d", h.kills, h.deaths); g.text(b, W / 2, 285, 3, .8f, .9f, 1, 1, 1); float bx = W / 2 - 180;
      if (ui.button(bx, 350, 360, 70, "REMATCH", 3.5f, 1)) startGame(a, G.humanTeam);
      if (ui.button(bx, 440, 360, 70, "MAIN MENU", 3.5f)) a.mode = M_MENU; }
  } else {
    bool back = a.back; a.back = false; a.c.playMode = false; menuScene(a);
    if (back) { if (a.mode == M_SET) { a.mode = a.setFrom; a.saveReq = true; } else if (a.mode != M_MENU) a.mode = M_MENU; }
    if (a.mode == M_MENU) {
      dim(g, 520, H, .6f); g.text("DEFUSAL", 50, 70, 9, 1, 1, 1); g.text("STRIKE", 50, 150, 9, 1, .6f, .1f); g.text("OFFLINE 5V5 BOMB DEFUSAL", 52, 232, 2.2f, .8f, .85f, 1);
      if (ui.button(50, 290, 380, 66, "PLAY", 3.5f, 1)) a.mode = M_SIDE; if (ui.button(50, 368, 380, 66, "SETTINGS", 3.5f)) { a.setFrom = M_MENU; a.mode = M_SET; }
      if (ui.button(50, 446, 380, 66, "HOW TO PLAY", 3.5f)) a.mode = M_HOW; if (ui.button(50, 524, 380, 66, "QUIT", 3.5f, 2)) a.quit = true;
      char b[64]; snprintf(b, 64, "MATCHES WON %d   LOST %d", S.wins, S.losses); g.text(b, 52, H - 36, 2, .8f, .8f, .8f); g.text("V1.0", W - 14, H - 26, 2, .7f, .7f, .7f, 1, 2);
    } else if (a.mode == M_SIDE) {
      dim(g, W, H, .7f); g.text("CHOOSE YOUR SIDE", W / 2, 50, 6, 1, 1, 1, 1, 1); float cw = 360, ch = 250, x0 = W / 2 - cw - 20, y0 = 140;
      g.rect(x0, y0, cw, ch, .45f, .3f, .1f, .9f); g.text("TERRORIST", x0 + cw / 2, y0 + 30, 4, 1, .8f, .4f, 1, 1); g.text("PLANT THE BOMB AT", x0 + cw / 2, y0 + 100, 2, 1, 1, 1, 1, 1); g.text("SITE A OR B AND", x0 + cw / 2, y0 + 128, 2, 1, 1, 1, 1, 1); g.text("HOLD IT DOWN", x0 + cw / 2, y0 + 156, 2, 1, 1, 1, 1, 1);
      if (ui.button(x0 + 40, y0 + ch - 60, cw - 80, 48, "PLAY AS T", 3, 1)) startGame(a, TEAM_T);
      float x1 = W / 2 + 20; g.rect(x1, y0, cw, ch, .1f, .2f, .45f, .9f); g.text("COUNTER-TERRORIST", x1 + cw / 2, y0 + 34, 3, .6f, .8f, 1, 1, 1); g.text("STOP THE PLANT OR", x1 + cw / 2, y0 + 100, 2, 1, 1, 1, 1, 1); g.text("DEFUSE THE C4", x1 + cw / 2, y0 + 128, 2, 1, 1, 1, 1, 1); g.text("BEFORE IT BLOWS", x1 + cw / 2, y0 + 156, 2, 1, 1, 1, 1, 1);
      if (ui.button(x1 + 40, y0 + ch - 60, cw - 80, 48, "PLAY AS CT", 3, 4)) startGame(a, TEAM_CT);
      static const char* DF[3] = {"EASY", "NORMAL", "HARD"}; ui.choice("BOT DIFFICULTY", S.difficulty, DF, 3, W / 2 - 300, 430, 600); if (ui.button(W / 2 - 120, 520, 240, 60, "BACK", 3)) a.mode = M_MENU;
    } else if (a.mode == M_HOW) {
      dim(g, W, H, .78f); g.text("HOW TO PLAY", 40, 24, 5, 1, .6f, .1f);
      static const char* L[] = {"5V5 AGAINST BOTS. FIRST TEAM TO WIN THE ROUNDS WINS.", "LEFT SIDE: DRAG TO MOVE.  RIGHT SIDE: DRAG TO AIM.", "FIRE, JUMP, RLD (RELOAD) AND WEAPON SLOT BUTTONS ARE ON SCREEN.",
        "T: SPAWN WITH THE C4. GO TO SITE A OR B, HOLD PLANT FOR 3 SECONDS.", "CT: STOP THE PLANT. NEAR THE C4 HOLD DEFUSE (5S WITH KIT, 10S WITHOUT).",
        "BOMB TIMER IS 40 SECONDS. HEADSHOTS DO BIG DAMAGE. ARMOR REDUCES IT.", "TAP BUY DURING THE FIRST SECONDS OF A ROUND TO SPEND MONEY.", "KILLS PAY $300, WINNING $3250, LOSING $1900.",
        "SNIPER: TAP SCOPE TO ZOOM. DEAD? YOU SPECTATE YOUR TEAM.", "CUSTOMIZE CROSSHAIR, VIEWMODEL, HUD AND GRAPHICS IN SETTINGS."};
      for (int i = 0; i < 10; i++) g.text(L[i], 40, 110 + i * 42, 2, .95f, .95f, 1); if (ui.button(40, H - 90, 240, 60, "BACK", 3)) a.mode = M_MENU;
    } else if (a.mode == M_SET) drawSettings(a, ui, W, H);
  }
  g.flush2(); a.c.frameEnd();
}
