package com.defusal.strike;

import android.app.NativeActivity;
import android.os.Build;
import android.os.Bundle;
import android.view.WindowManager;

public class MainActivity extends NativeActivity {
  @Override protected void onCreate(Bundle b) {
    super.onCreate(b);
    getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
    if (Build.VERSION.SDK_INT >= 28) {
      WindowManager.LayoutParams lp = getWindow().getAttributes();
      lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
      getWindow().setAttributes(lp);
    }
  }
  @Override public void onWindowFocusChanged(boolean focus) {
    super.onWindowFocusChanged(focus);
    if (focus) getWindow().getDecorView().setSystemUiVisibility(0x1706); // immersive sticky, hide bars
  }
}
