# Defusal Strike - offline 5v5 bomb defusal FPS (C++ / OpenGL ES 3 / Android)

Pure C++ game (NativeActivity + EGL + GLES3, no engine). 1 map, 2 bomb sites, 10 players (you + 4 bots vs 5 bots),
4 guns (pistol, SMG, rifle, sniper) + knife + C4, buy menu, economy, spectator, minimap, settings for graphics /
viewmodel / crosshair / HUD / controls, saved to internal storage.

## Get the APK (no setup): GitHub Actions
1. Create a GitHub repo, push this folder.  2. Actions tab -> "Build APK" -> run (runs on push too).
3. Download the `DefusalStrike-apk` artifact, unzip, install `app-release.apk` (signed with the debug key).

## Or build locally
Android Studio (Hedgehog+): open this folder, let it install NDK + CMake, Build > Build APK(s).
CLI: `gradle assembleRelease` (Gradle 8.7, JDK 17, Android SDK + NDK installed).

## Verify game logic without Android
`g++ -std=c++17 -O2 -o sim tools/sim.cpp && ./sim 1`  (headless bot-vs-bot matches; arg = difficulty 0-2)

## Layout
app/src/main/cpp: game.h (rules, bots, nav), render.h (GLES renderer), ui.h (HUD/menus/settings), main.cpp (Android glue).
