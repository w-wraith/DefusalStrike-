// Headless bot-vs-bot simulation: verifies AI, pathing and the full bomb/round loop.
#include "../app/src/main/cpp/game.h"
int main(int argc, char** argv) {
  Settings S; S.difficulty = argc > 1 ? atoi(argv[1]) : 1; Game g; g.init(&S); g.autoHuman = true;
  // nav sanity: every spawn and site must reach each other
  std::vector<V3> p; int bad = 0;
  for (int t = 0; t < 2; t++) for (int i = 0; i < 5; i++) for (int s = 0; s < 2; s++) if (!g.map.findPath(g.map.spawn[t][i], g.map.siteC[s], p)) bad++;
  printf("nav unreachable pairs: %d\n", bad);
  int matches = 0, rounds = 0, tw = 0, cw = 0;
  for (int m = 0; m < 6; m++) {
    g.startMatch(m & 1); int ticks = 0;
    int lastRound = 0;
    while (g.phase != PH_END && ticks < 200000) { g.update(1.f / 30, Input()); ticks++; if (g.round != lastRound) lastRound = g.round; }
    matches++; rounds += g.round; tw += g.score[0]; cw += g.score[1];
    printf("match %d: T %d - CT %d, rounds %d, ticks %d, end phase %d\n", m, g.score[0], g.score[1], g.round, ticks, g.phase);
  }
  printf("plants %d defuses %d blasts %d | total T wins %d CT wins %d\n", g.statPlants, g.statDefuses, g.statBlasts, tw, cw);
  return 0;
}
